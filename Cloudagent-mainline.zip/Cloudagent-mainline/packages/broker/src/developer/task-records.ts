// Spec 025 phase 25b: a developer task's records, owner key, status and failure rules, event text
// and audit records. No I/O; aws/developer-tasks.ts and the broker's result hook call these.
import { createHash } from "node:crypto";
import {
  inertName,
  AiToolTurnRecordSchema,
  DEVELOPER_EVENT_TEXT_MAX,
  DEVELOPER_FAILURE_MESSAGE_MAX,
  DEVELOPER_TASK_OWNER_ISSUER,
  PullRequestLifecycleResultSchema,
  PullRequestResultSchema,
  TURN_TEXT_LIMIT,
  UNKNOWN_CLIENT_NAME,
  WORKFLOW_APPLICATION_PLAN_NOT_APPROVABLE_PREFIX,
  aiToolTurnRecordKeys,
  capText,
  lastAssistantResponse,
  redactAndCap,
  redactText,
  slackThreadSubject,
  slackThreadUrl,
  type AiToolTurnRecord,
  type DeveloperRequester,
  type DeveloperTaskEvent,
  type DeveloperTaskFailure,
  type DeveloperTaskFailureCategory,
  type DeveloperTaskShare,
  type DeveloperTaskStatus,
  type Operation,
  type WorkflowSnapshot,
  type WorkflowReviewBase,
  type DeveloperSignInMethod,
} from "@agentx/contracts";
import type { AuthenticatedIdentity } from "../auth.js";
import { isHeartbeat, modelCallView } from "./model-call-view.js";
import type { ShareDecision } from "./share.js";
import type { PlanGroundingHold, PlanSelfCheckState } from "./plan-self-check.js";
import type { PlanUnreadableCategory } from "./plan-check-summary.js";
import type { AutoFixAsk } from "./autofix-messages.js";

/** Whether a block reason is one of the two that send a task back to plan review for a corrected E2E plan: a source reference that does not match the candidate, or an application plan that can no longer run as written. */
export function isE2EPlanCorrectionBlockReason(blockReason: string | undefined): boolean {
  return blockReason !== undefined && (blockReason === E2E_PLAN_REFERENCE_INVALID_BLOCK_REASON || blockReason.startsWith(WORKFLOW_APPLICATION_PLAN_NOT_APPROVABLE_PREFIX));
}

export const E2E_PLAN_REFERENCE_INVALID_BLOCK_REASON = "The approved feature E2E plan references a source operation that does not match the protected candidate. Request changes and submit a corrected E2E plan before coding resumes.";

export interface CounterKey { pk: string; sk: string }
export interface WorkspaceCharge { member: CounterKey; organization: CounterKey }

/** DEVTASK#<taskId> / META: the task. */
/** #651: one usage record of a task's runs: when, its cost (null when the provider gave none) and its tokens. */
export interface TaskRunSpend { at: string; usd: number | null; inputTokens: number; outputTokens: number }

/** #651: the totals kept on the task as its usage is recorded. */
export interface TaskSpendTotals { spentUsd?: number; spentInputTokens?: number; spentOutputTokens?: number; spentRuns?: number; spentUnpricedRuns?: number; spentUpdatedAt?: string }

/** #651: the marker of one usage record counted on its task, in its own partition: a replayed record finds it and is not counted again. */
export const taskSpendMarkerKey = (taskId: string, usageId: string) => ({ pk: `TASKSPEND#${taskId}`, sk: usageId });

/** #651: what the task has cost so far, from its totals: priced dollars, tokens, records and unpriced records, and when the newest was counted. */
export function taskSpent(task: TaskSpendTotals): { usd: number; inputTokens: number; outputTokens: number; runs: number; unpricedRuns: number; updatedAt: string } | undefined {
  const runs = task.spentRuns;
  if (typeof runs !== "number" || runs <= 0) return undefined;
  const count = (value: unknown) => (typeof value === "number" && Number.isFinite(value) && value > 0 ? Math.round(value) : 0);
  const usd = typeof task.spentUsd === "number" && Number.isFinite(task.spentUsd) && task.spentUsd > 0 ? task.spentUsd : 0;
  // Cents are what a person reads; the running sum of floats is rounded once, here.
  return { usd: Math.round(usd * 10_000) / 10_000, inputTokens: count(task.spentInputTokens), outputTokens: count(task.spentOutputTokens), runs: count(runs), unpricedRuns: count(task.spentUnpricedRuns), updatedAt: task.spentUpdatedAt ?? "" };
}

export interface DeveloperTaskRecord extends TaskSpendTotals {
  pk: string;
  sk: "META";
  entityType: "DEVELOPER_TASK";
  taskId: string;
  developerId: string;
  provider: DeveloperSignInMethod;
  developerName: string;
  slackUserId?: string;
  client: string;
  project: string;
  title: string;
  workspaceId: string;
  ownerKey: string;
  conversationId: string;
  startingRevision: number;
  charge: WorkspaceCharge;
  /** C1: whether the task is shared to its channel, and how. */
  shared: boolean;
  share?: TaskShare;
  /** C1: every write of `share` replaces the whole map, conditioned on this number. */
  shareVersion?: number;
  /** Serializes append-only task Canvas lineage mutations without advancing workflow revision. */
  canvasLineageVersion?: number;
  canvasCloseoutVersion?: number;
  canvasCloseoutRetry?: { requestId: string; workflowRevision: number; manifestDigest?: string; actorId: string; requestedAt: string; dispatchAttempt: number };
  createdAt: string;
  updatedAt: string;
closedAt?: string;
  /**
   * Decision 134: the requester pressed Stop on a request that started Quick on its own. Remembered until the task can
   * close (setup finished, or the running step was cancelled); then the broker closes it with this press's request ID.
   */
  stopRequest?: { userId: string; requestId: string; at: string };
  /**
   * When a finished workflow task (all its pull requests merged, or its workflow closed) gave back its workspace slot and
   * its workspace. A closed task gives them back with its close instead, and has none.
   */
  releasedAt?: string;
  /** When that release claimed the workspace (CLOSING) before deleting its compute; removed once it is released. */
  releaseClaimedAt?: string;
  workflow?: WorkflowSnapshot;
  /** The commit each repository's preparation checked out, from the prepare result; the task's base until one is pinned. */
  preparedBase?: WorkflowReviewBase;
  /** Spec 061: why the planner's last answer could not be read, kept for Retry planning; `workflowRevision` is the blocked step's revision. */
  planUnreadable?: { workflowRevision: number; errors: string[]; /** The fixed category of the problem (never the validator's words), for the owner's message. */ category?: PlanUnreadableCategory; /** Whether AgentX already asked the planner once more by itself. */ autoRetried?: true };
  /** AUTOFIX: why Rovara asked the owner instead of fixing a blocked step by itself, for the blocked revision `workflowRevision` (see autofix-messages.ts). */
  autofixAsk?: AutoFixAsk;
  /** Plan self-check: which document version the automatic revision budget is for, and how much is spent (see plan-self-check.ts). */
  planSelfCheck?: PlanSelfCheckState;
  /** T7c: the coding plan the task is holding back while its must-not-change checks run on the current app; the plan is not yet submitted, so there is nothing to approve. */
  planGrounding?: PlanGroundingHold;
  /** T7c: the owner closed the task while the plan was held (the held plan's digest): the finish clears the hold and asks nobody anything. */
  planGroundingAbandoned?: string;
  /** Broker-private fence requiring a new E2E plan after the protected source disproved an approved plan reference. */
  e2ePlanCorrection?: { artifactId: string; artifactSha256: string; candidateDigest: string; reasonCode: string; requiredE2E: true };
  /** Gap 2: how many thread replies are saved for the task (NOTE# items). */
  threadNoteCount?: number;
  /** Gap 2: the newest saved reply's receivedAt already given to a planning or coding step; each reply is given once. */
  threadNotesFedThrough?: string;
  /**
   * The thread replies received after this and through `threadNotesFedThrough` were given to steps since the last plan
   * that was stored; they are what that plan's "why" quotes. Set to `threadNotesFedThrough` when a plan is stored; absent
   * until the first one is.
   */
  threadNotesFedFrom?: string;
  /** The owner's original request, redacted and cut to 4,000 characters; the first entry of each plan's "why". Tasks created earlier have none. */
  requestText?: string;
}

/** C1: a shared task's thread, as the task record keeps it. */
export interface TaskShare {
  teamId: string;
  channelId: string;
  channelName?: string;
  mode: "view" | "continue";
  sharedReason: "requested" | "required";
  modeReason?: "continue_not_allowed";
  sharedAt: string;
  threadTs?: string;
  postFailedAt?: string;
}

export function taskShare(decision: ShareDecision, teamId: string, sharedAt: string): TaskShare {
  return {
    teamId, channelId: decision.channelId,
    ...(decision.channelName === undefined ? {} : { channelName: decision.channelName }),
    mode: decision.mode, sharedReason: decision.sharedReason,
    ...(decision.modeReason === undefined ? {} : { modeReason: decision.modeReason }),
    sharedAt,
  };
}

/** The wire view of a share: a thread link only once the notifier has posted (C6). */
export function shareView(share: TaskShare): DeveloperTaskShare {
  return {
    mode: share.mode, channelId: share.channelId,
    ...(share.channelName === undefined ? {} : { channelName: share.channelName }),
    sharedReason: share.sharedReason,
    ...(share.modeReason === undefined ? {} : { modeReason: share.modeReason }),
    ...(share.threadTs === undefined ? {} : { threadUrl: slackThreadUrl({ teamId: share.teamId, channelId: share.channelId, threadTs: share.threadTs }) }),
    ...(share.postFailedAt === undefined ? {} : { postFailed: true }),
  };
}

/** The shared thread's Slack subject, the key of its Slack-side records (ruling F11: contracts' builder, which validates). */
export const sharedSubject = (share: TaskShare & { threadTs: string }): string =>
  slackThreadSubject({ teamId: share.teamId, channelId: share.channelId, threadTs: share.threadTs });

/** DEVELOPER#<developerId> / TASK#<createdAt>#<taskId>: the task index of FR-017. */
export interface DeveloperTaskIndexRecord {
  pk: string;
  sk: string;
  entityType: "DEVELOPER_TASK_INDEX";
  taskId: string;
  project: string;
  title: string;
  client: string;
  status: DeveloperTaskStatus;
  shared: boolean;
  startingRevision: number;
  workspaceId: string;
  createdAt: string;
  updatedAt: string;
}

/** WORKSPACE#<workspaceId> / DEVELOPER_TASK: how a worker callback finds the task (R2, R3). */
export interface DeveloperTaskPointerRecord {
  pk: string;
  sk: "DEVELOPER_TASK";
  entityType: "DEVELOPER_TASK_POINTER";
  taskId: string;
  developerId: string;
  requester: DeveloperRequester;
  conversationId: string;
  firstRequestId: string;
  /** The first instructions, until the prepare's result queues them (R3). */
  pendingPrompt?: string;
  /** The first plan-only operation is selected by the broker, never by the request. */
  pendingWorkflowMode?: "PLAN" | "IMPLEMENT";
  /** Set when the task was cancelled before its instructions ran (R16). */
  cancelledAt?: string;
}

/** GITHUB_PR#<owner/repo> / PR#<number>: exact reverse link from a published PR to its task. */
export interface GithubWorkflowPullRequestRecord {
  pk: string;
  sk: string;
  entityType: "GITHUB_WORKFLOW_PR";
  repositoryFullName: string;
  repositoryId: string;
  number: number;
  url: string;
  taskId: string;
  workspaceId: string;
  candidateDigest: string;
  createdAt: string;
}

export const taskKey = (taskId: string) => ({ pk: `DEVTASK#${taskId}`, sk: "META" as const });
/** The item stored with a plan: which comments the planner answered in it (the Slack card for the plan reads it). */
export const plannerRepliesKey = (taskId: string, artifactId: string) => ({ pk: `DEVTASK#${taskId}`, sk: `PLANREPLIES#${artifactId}` });
export const taskIndexKey = (developerId: string, createdAt: string, taskId: string) => ({ pk: `DEVELOPER#${developerId}`, sk: `TASK#${createdAt}#${taskId}` });
export const taskPointerKey = (workspaceId: string) => ({ pk: `WORKSPACE#${workspaceId}`, sk: "DEVELOPER_TASK" as const });
export function githubWorkflowPullRequestKey(repositoryFullName: string, number: number) {
  const match = /^([A-Za-z0-9_.-]+)\/([A-Za-z0-9_.-]+)$/.exec(repositoryFullName);
  if (!match || !Number.isSafeInteger(number) || number < 1) throw new Error("GitHub pull request identity is invalid");
  return { pk: `GITHUB_PR#${repositoryFullName.toLowerCase()}`, sk: `PR#${String(number).padStart(10, "0")}` };
}
export const startIdempotencyKey = (developerId: string, requestId: string) => ({ pk: `IDEMPOTENCY#${developerId}#DEVTASK`, sk: `REQUEST#${requestId}` });

export const taskOwnerSubject = (developerId: string, taskId: string): string => `${developerId}/${taskId}`;

/** FR-017: the same function as ownerKeyForSubject, so every workspace handler accepts it. */
export function taskOwnerKey(developerId: string, taskId: string): string {
  return createHash("sha256").update(DEVELOPER_TASK_OWNER_ISSUER).update("\0").update(taskOwnerSubject(developerId, taskId)).digest("hex");
}

export interface OperationFacts { id: string; kind: string; status: string; error?: string | undefined; createdAt: string; updatedAt?: string | undefined; fence?: number | undefined }

const LIVE = new Set(["ACCEPTED", "DISPATCHING", "RUNNING", "CANCEL_REQUESTED"]);

/**
 * Oldest first. F9: exported so Task 10 reuses it rather than redeclaring it. Two operations can
 * share a millisecond, so a tie goes to the fence: each writer operation takes the workspace's
 * next fence, so the later one has the higher fence.
 */
export const byCreated = (left: OperationFacts, right: OperationFacts) =>
  left.createdAt < right.createdAt ? -1 : left.createdAt > right.createdAt ? 1 : (left.fence ?? 0) - (right.fence ?? 0);

/** The newest task or publish operation: what the developer last asked for (R4). */
export function currentOperation(operations: readonly OperationFacts[]): OperationFacts | undefined {
  return operations.filter((operation) => operation.kind === "task" || operation.kind === "publish").sort(byCreated).at(-1);
}

const DISPATCH_OR_COMPUTE = /^RUNTIME_UNAVAILABLE:/;
const WORKER_CALLBACK_REFUSED = /^RUNTIME_UNAVAILABLE: worker callback pull-request(?:-update)? failed with HTTP \d{3}$/;
/** F18: also matches the worker devcontainer's "timeout:<ms>" error text (packages/worker/src/devcontainer.ts). */
const TIMED_OUT = /\btimed? ?out\b|\btimeout:/i;

/** R5. */
export function failureCategory(kind: string, status: string, error: string | undefined): DeveloperTaskFailureCategory {
  if (status === "INTERRUPTED") return "interrupted";
  // A worker that ran and whose callback the control plane refused (opening the pull request on GitHub failed, say) was
  // available: that is the step failing, not "no worker was free".
  if (error !== undefined && DISPATCH_OR_COMPUTE.test(error) && !WORKER_CALLBACK_REFUSED.test(error)) return "worker_unavailable";
  if (kind === "prepare") return "setup_failed";
  if (kind === "publish") return "publication_failed";
  if (error !== undefined && TIMED_OUT.test(error)) return "timed_out";
  return "task_failed";
}

const COMPUTE_LOST = /^RUNTIME_UNAVAILABLE: workspace compute was lost\b/;
/** #154: a setup that never finished cannot be continued, so "retry the request" is wrong there. */
export const COMPUTE_LOST_DURING_SETUP = "workspace compute was lost during setup; close this task and start a new one";

function failureOf(kind: string, status: string, error: string | undefined): DeveloperTaskFailure {
  const category = failureCategory(kind, status, error);
  if (kind !== "prepare") {
    // redactAndCap redacts then caps surrogate-pair-safely (a plain .slice can split an emoji).
    return { category, message: redactAndCap(error ?? `the ${kind} operation ended ${status}`, DEVELOPER_FAILURE_MESSAGE_MAX).text };
  }
  const text = error !== undefined && COMPUTE_LOST.test(error) ? COMPUTE_LOST_DURING_SETUP : error ?? `the ${kind} operation ended ${status}`;
  return { category, stage: "setup", message: redactAndCap(text, DEVELOPER_FAILURE_MESSAGE_MAX).text };
}

export interface DerivedStatus {
  status: DeveloperTaskStatus;
  failure?: DeveloperTaskFailure;
  closing: boolean;
  current?: OperationFacts;
  /** #225: the prepare whose failure the task reads as: its events and its last change are the task's. */
  failedPrepare?: OperationFacts;
}

/** R4's table. */
export function deriveTaskStatus(input: {
  closedAt?: string | undefined;
  workspaceStatus: string;
  pointer?: { pendingPrompt?: string | undefined; cancelledAt?: string | undefined } | undefined;
  operations: readonly OperationFacts[];
}): DerivedStatus {
  const closing = input.workspaceStatus === "CLOSING" || input.operations.some((operation) => operation.kind === "close" && LIVE.has(operation.status));
  const current = currentOperation(input.operations);
  const withCurrent = current === undefined ? {} : { current };
  if (input.closedAt !== undefined || input.workspaceStatus === "CLOSED") return { status: "CLOSED", closing: false, ...withCurrent };
  if (input.pointer?.cancelledAt !== undefined && current === undefined) return { status: "CANCELLED", closing };
  if (input.workspaceStatus === "PREPARATION_FAILED") {
    const prepare = input.operations.filter((operation) => operation.kind === "prepare").sort(byCreated).at(-1);
    return { status: "FAILED", closing, failure: failureOf("prepare", prepare?.status ?? "FAILED", prepare?.error), ...(prepare === undefined ? {} : { failedPrepare: prepare }) };
  }
  if (input.pointer?.pendingPrompt !== undefined || input.workspaceStatus === "PREPARING" || current === undefined) return { status: "STARTING", closing };
  if (LIVE.has(current.status)) return { status: "RUNNING", closing, current };
  const status = current.status as "SUCCEEDED" | "FAILED" | "CANCELLED" | "INTERRUPTED";
  return {
    status, closing, current,
    ...(status === "FAILED" || status === "INTERRUPTED" ? { failure: failureOf(current.kind, status, current.error) } : {}),
  };
}

export interface StoredEvent { sequence: number; type: string; timestamp: string; payload: unknown }

// capText caps surrogate-pair-safely (a plain .slice can split an emoji at the boundary).
const text = (value: string) => capText(redactText(value).replace(/\s+/g, " ").trim(), DEVELOPER_EVENT_TEXT_MAX).text;
const field = (payload: unknown, name: string): unknown => (payload && typeof payload === "object" ? (payload as Record<string, unknown>)[name] : undefined);

/** One worker event as a line the developer can read, or undefined for streaming noise. */
export function taskEvent(event: StoredEvent): DeveloperTaskEvent | undefined {
  const at = event.timestamp;
  const payload = event.payload;
  switch (event.type) {
    case "lifecycle":
    case "result": {
      const status = field(payload, "status");
      return typeof status === "string" ? { at, kind: "status", text: text(`Worker status: ${status}`) } : undefined;
    }
    case "error": {
      const message = field(payload, "message");
      return { at, kind: "error", text: text(typeof message === "string" ? message : "the worker reported an error") };
    }
    case "tool_start":
    case "tool_end": {
      const name = field(payload, "toolName");
      const tool = typeof name === "string" ? name : "a tool";
      const verb = event.type === "tool_start" ? "Started" : field(payload, "isError") === true ? "Failed" : "Finished";
      return { at, kind: "tool", text: text(`${verb} ${tool}`) };
    }
    case "progress": {
      // PLANINC-1: a model failure, retry or wait reads as a fixed sentence; the provider's own text is never shown. null: a sanitized payload with nothing to show.
      const modelCall = modelCallView(payload);
      if (modelCall === null) return undefined;
      if (modelCall !== undefined) return { at, kind: modelCall.kind, text: text(modelCall.text) };
      const message = field(payload, "message");
      if (typeof message === "string") return { at, kind: "progress", text: text(message) };
      // F7: reuse lastAssistantResponse (Task 2) instead of a second copy of its block-extraction logic.
      const said = lastAssistantResponse([{ payload }]);
      return said === undefined ? undefined : { at, kind: "message", text: text(said) };
    }
    default:
      return undefined;
  }
}

/** The newest `count` readable events, returned oldest first. A heartbeat (one a minute) is kept only when it is the newest, so a long wait never pushes a failure or a retry out of the list. */
export function recentTaskEvents(newestFirst: readonly StoredEvent[], count: number): DeveloperTaskEvent[] {
  const picked: DeveloperTaskEvent[] = [];
  let heartbeatKept = false;
  for (const event of newestFirst) {
    if (picked.length >= count) break;
    if (event.type === "progress" && isHeartbeat(event.payload)) {
      if (heartbeatKept) continue;
      heartbeatKept = true;
    }
    const readable = taskEvent(event);
    if (readable !== undefined) picked.push(readable);
  }
  return picked.reverse();
}

export interface TurnParty {
  taskId: string;
  developerId: string;
  provider: DeveloperSignInMethod;
  developerName: string;
  slackUserId?: string | undefined;
  client: string;
  workspaceId?: string | undefined;
  settingsRevision?: number | undefined;
}

/** F8: the turn record's party, built from a task record, so Task 11's routes and result hook
 * do not each repeat this literal. */
export function partyOfTask(task: DeveloperTaskRecord): TurnParty {
  return {
    taskId: task.taskId, developerId: task.developerId, provider: task.provider, developerName: task.developerName,
    slackUserId: task.slackUserId, client: task.client, workspaceId: task.workspaceId, settingsRevision: task.startingRevision,
  };
}

/**
 * R12: one immutable AI-tool turn record and its keys. Free text only through redactAndCap, so a
 * secret-looking request or response never reaches storage. Each call is one phase (accepted,
 * completed or refused) of one action; the caller's turnId (a fresh id per phase, or the
 * operation's id for a completed phase) keeps aiToolTurnRecordKeys' sk (TURN#<receivedAt>#<turnId>)
 * distinct per phase, so the three phases of one action are three rows, written once each with
 * PutItem and never updated.
 */
export function aiToolTurn(input: {
  party: TurnParty;
  turnId: string;
  action: AiToolTurnRecord["action"];
  phase: AiToolTurnRecord["phase"];
  outcome: AiToolTurnRecord["outcome"];
  receivedAt: string;
  finishedAt: string;
  request: string;
  response: string;
  operationId?: string | undefined;
  errorCode?: string | undefined;
  /** C25: the AgentX admin who took this action on the developer's task (a share mode change). */
  admin?: { issuer: string; subject: string; displayName?: string } | undefined;
}): Record<string, unknown> & AiToolTurnRecord {
  const request = redactAndCap(input.request, TURN_TEXT_LIMIT);
  const response = redactAndCap(input.response, TURN_TEXT_LIMIT);
  const { party } = input;
  const record = AiToolTurnRecordSchema.parse({
    origin: "ai_tool",
    taskId: party.taskId,
    turnId: input.turnId,
    action: input.action,
    phase: input.phase,
    developer: {
      developerId: party.developerId,
      provider: party.provider,
      displayName: party.developerName.slice(0, 200) || "developer",
      ...(party.slackUserId === undefined ? {} : { slackUserId: party.slackUserId }),
    },
    client: party.client,
    ...(input.admin === undefined ? {} : { admin: {
      issuer: input.admin.issuer.slice(0, 512), subject: input.admin.subject.slice(0, 256),
      ...(input.admin.displayName === undefined ? {} : { displayName: input.admin.displayName.slice(0, 200) }),
    } }),
    receivedAt: input.receivedAt,
    ...(party.settingsRevision === undefined ? {} : { settingsRevision: party.settingsRevision }),
    ...(party.workspaceId === undefined ? {} : { workspaceId: party.workspaceId }),
    ...(input.operationId === undefined ? {} : { operationId: input.operationId }),
    outcome: input.outcome,
    startedAt: input.receivedAt,
    finishedAt: input.finishedAt,
    durationMs: Math.max(0, Date.parse(input.finishedAt) - Date.parse(input.receivedAt)),
    requestText: request.text,
    responseText: response.text,
    ...(request.truncated || response.truncated ? { textTruncated: true } : {}),
    ...(input.errorCode === undefined ? {} : { error: { code: input.errorCode.slice(0, 64) } }),
  });
  return { ...aiToolTurnRecordKeys(record), ...record };
}

/** A terminal operation status as a completed turn record's outcome. */
export const OUTCOME: Record<string, AiToolTurnRecord["outcome"]> = { SUCCEEDED: "succeeded", FAILED: "failed", CANCELLED: "cancelled", INTERRUPTED: "interrupted" };

/**
 * R12: the result of a developer's task or publish operation, or of the push of a workflow task's approved fix (a
 * maintain operation). Its turnId and receivedAt are the
 * operation's ID and creation time, so its key is fixed and a repeated result cannot write it
 * twice. The response text is the result summary (FR-037), redacted and capped by aiToolTurn.
 */
export function completedTurn(input: {
  task: DeveloperTaskRecord;
  pointer: Pick<DeveloperTaskPointerRecord, "firstRequestId">;
  operation: Pick<Operation, "id" | "kind" | "requestId" | "createdAt"> & { result?: unknown; error?: string | undefined };
  status: string;
  events: readonly StoredEvent[];
  now: string;
}): Record<string, unknown> & AiToolTurnRecord {
  const { operation } = input;
  const ended = `ended ${input.status}${operation.error ? `: ${operation.error}` : ""}`;
  const published = operation.kind === "publish" ? PullRequestResultSchema.safeParse(operation.result) : undefined;
  const pushed = operation.kind === "maintain" ? PullRequestLifecycleResultSchema.safeParse(operation.result) : undefined;
  const response = operation.kind === "publish"
    ? (published?.success ? `Pull request ${published.data.url}` : `The pull request ${ended}`)
    : operation.kind === "maintain"
      ? (pushed?.success ? `Pushed the fix to pull request ${pushed.data.url}` : `The fix push ${ended}`)
      : lastAssistantResponse(input.events) ?? `The task ${ended}`;
  return aiToolTurn({
    party: partyOfTask(input.task),
    turnId: operation.id,
    action: operation.kind === "publish" || operation.kind === "maintain" ? "pull_request" : operation.requestId === input.pointer.firstRequestId ? "start" : "continue",
    phase: "completed",
    outcome: OUTCOME[input.status] ?? "failed",
    receivedAt: operation.createdAt,
    finishedAt: input.now,
    request: "",
    response,
    operationId: operation.id,
  });
}

/** Moved to the contracts package so the MCP server marks names the same way (final review M7). */
export { inertName };

/** The client name a task keeps when the Slack workflow started it, so its footer can tell Slack from an AI tool. */
export const SLACK_CLIENT_NAME = "Slack";

/** The session ID of the caller the Slack workflow starts tasks as (slack-workflow-caller.ts). */
export const SLACK_WORKFLOW_SESSION_ID = "slack-workflow";

/** What a person reads for the owner when no name anyone knows is on record. */
export const TASK_OWNER_LABEL = "the task owner";
const SLACK_FALLBACK_NAME = /^Slack user U[A-Z0-9]+$/;

/** The owner's name for people to read: "the task owner" when it is empty or only the Slack-ID fallback of a Slack-started task. */
export function taskOwnerLabel(name: string): string {
  const trimmed = name.trim();
  return trimmed === "" || SLACK_FALLBACK_NAME.test(trimmed) ? TASK_OWNER_LABEL : name;
}

/**
 * FR-023. The client is one of the fixed names cleanClientName gives, or "Slack" for a task the Slack workflow
 * started, so it needs no escaping. A task stored before Slack was kept as a client is told by its Slack-ID name.
 */
export function developerFooter(name: string, client: string): string {
  const label = taskOwnerLabel(name);
  const owner = label === TASK_OWNER_LABEL ? label : inertName(label);
  const slack = client === SLACK_CLIENT_NAME || (client === UNKNOWN_CLIENT_NAME && SLACK_FALLBACK_NAME.test(name.trim()));
  return `Requested by ${owner} via AgentX, started from ${slack ? SLACK_CLIENT_NAME : client}`;
}

/** The identity every workspace handler sees for a developer task: its own owner key (FR-021). */
export function developerTaskIdentity(task: Pick<DeveloperTaskRecord, "taskId" | "developerId" | "provider" | "developerName" | "client">): AuthenticatedIdentity {
  return {
    issuer: DEVELOPER_TASK_OWNER_ISSUER,
    subject: taskOwnerSubject(task.developerId, task.taskId),
    ownerKey: taskOwnerKey(task.developerId, task.taskId),
    isAdministrator: false,
    claims: {},
    developer: { developerId: task.developerId, provider: task.provider, name: task.developerName, client: task.client, taskId: task.taskId },
  };
}
