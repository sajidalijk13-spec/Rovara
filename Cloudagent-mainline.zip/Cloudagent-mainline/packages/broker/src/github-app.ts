import { createHash, createSign } from "node:crypto";
import { z } from "zod";
import { PULL_REQUEST_BODY_MAX_CHARS, agentXError, createCandidateManifest, isSafeE2ESourcePath, type AgentXError, type ClientRepositoriesResponse, type E2ESourceSnapshot } from "@agentx/contracts";
import type { RepositoryAccess, RepositoryCredential } from "./repository-access.js";
import type { GithubMergeReadBudget } from "./aws/workflow-merge-recovery.js";

// Spec 065b: what installedRepositories reads of GitHub's answers.
const InstallationsSchema = z.array(z.object({
  id: z.number().int().positive(),
  account: z.object({ login: z.string(), type: z.enum(["User", "Organization"]) }),
  repository_selection: z.enum(["all", "selected"]),
  suspended_at: z.string().nullable().optional(),
}));
const InstallationRepositoriesSchema = z.object({
  repositories: z.array(z.object({ id: z.number().int().positive(), full_name: z.string(), private: z.boolean(), default_branch: z.string() })),
});

const GITHUB_APP_ID = /^[1-9][0-9]*$/;
const FILE_AT_COMMIT_MAX_BYTES = 20_971_520;
const FILE_AT_COMMIT_TIMEOUT_MS = 8_000;
const READ_TOKEN_REUSE_MS = 5 * 60_000;

export interface GitHubAppCredentialProviderOptions {
  credentialRef: string;
  /** The App's id, or a function that reads it when first needed: an install's control plane
   * deploys before its GitHub App exists, and then reads the id from the App's secret. */
  appId: string | (() => Promise<string>);
  getPrivateKey: () => Promise<string>;
  fetchImplementation?: typeof fetch;
  now?: () => number;
}

export interface GitHubPullRequestInput {
  repositoryUrl: string;
  headBranch: string;
  baseBranch: string;
  title: string;
  body?: string;
  /** Spec 025 FR-023: opens the pull request as a draft; GitHub's default applies when absent. */
  draft?: boolean;
}

export interface GitHubPullRequestResult {
  number: number;
  url: string;
  reconciled: boolean;
  /** Set when the pull request was asked to be a draft, GitHub refused drafts for this repository, and it was opened once as a normal pull request instead (INTG1). */
  draftRefused?: true;
}

/** The line a pull request opened in place of a refused draft starts with, so a reviewer is told it is not a draft and must not be merged unreviewed (INTG1). */
export const DRAFT_REFUSED_PULL_REQUEST_NOTE = "Draft pull requests are not available for this repository, so this one is open for review. Do not merge it until it has been reviewed.";

/** A pull request's description with the draft-refused note first, cut at its end so the whole stays within GitHub's limit. */
export function pullRequestBodyWithDraftNote(body: string | undefined): string {
  if (body === undefined || body === "") return DRAFT_REFUSED_PULL_REQUEST_NOTE;
  const separator = "\n\n";
  let room = Math.max(0, PULL_REQUEST_BODY_MAX_CHARS - DRAFT_REFUSED_PULL_REQUEST_NOTE.length - separator.length);
  // Cut between characters: a surrogate pair is never split at the end.
  if (room < body.length && room > 0 && /[\uD800-\uDBFF]/u.test(body.charAt(room - 1))) room -= 1;
  return `${DRAFT_REFUSED_PULL_REQUEST_NOTE}${separator}${body.slice(0, room)}`;
}

/**
 * Why GitHub answered 422 to a pull request creation, from a fixed list. GitHub's own text is only matched against, never kept: it is user content and goes nowhere (not into the
 * error, a log or a record). `draft-unsupported` is the answer to a draft request on a private repository whose plan has no drafts.
 */
type PullRequestRefusal = "draft-unsupported" | "no-commits" | "head-not-found" | "base-not-found" | "already-exists" | "unknown";
const PULL_REQUEST_REFUSAL_SENTENCES: Record<PullRequestRefusal, string> = {
  "draft-unsupported": "this repository does not allow draft pull requests",
  "no-commits": "the head branch has no commits that the base branch lacks",
  "head-not-found": "GitHub cannot find the head branch",
  "base-not-found": "GitHub cannot find the base branch",
  "already-exists": "a pull request for this branch already exists",
  unknown: "GitHub rejected the pull request and gave a reason AgentX does not recognise",
};
const MAX_REFUSAL_BODY_CHARS = 16_384;

/** The body's first 16 KiB, read through the stream so that a larger body is never read in full; a body that goes on past that is not read as JSON (it cannot be one of the short answers listed). */
async function boundedRefusalText(response: Response): Promise<string | undefined> {
  if (response.body === null) return "";
  const reader = response.body.getReader();
  const chunks: Uint8Array[] = [];
  let total = 0;
  try {
    for (;;) {
      const next = await reader.read() as { done: boolean; value?: Uint8Array };
      if (next.done || next.value === undefined) break;
      chunks.push(next.value);
      total += next.value.byteLength;
      if (total > MAX_REFUSAL_BODY_CHARS) { await reader.cancel().catch(() => undefined); return undefined; }
    }
  } catch { return undefined; }
  return Buffer.concat(chunks).toString("utf8");
}

async function pullRequestRefusalOf(response: Response): Promise<PullRequestRefusal> {
  let parsed: unknown;
  try {
    const text = await boundedRefusalText(response);
    if (text === undefined) return "unknown";
    parsed = JSON.parse(text);
  } catch { return "unknown"; }
  if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) return "unknown";
  const errors = (parsed as { errors?: unknown }).errors;
  if (!Array.isArray(errors)) return "unknown";
  const found = new Set<PullRequestRefusal>();
  for (const item of errors.slice(0, 20)) {
    if (!item || typeof item !== "object" || Array.isArray(item)) continue;
    const { message, field, code } = item as { message?: unknown; field?: unknown; code?: unknown };
    const text = typeof message === "string" ? message.toLowerCase() : "";
    if (/draft pull requests are not supported/.test(text)) found.add("draft-unsupported");
    else if (/^no commits between /.test(text)) found.add("no-commits");
    else if (/^a pull request already exists/.test(text)) found.add("already-exists");
    else if (code === "invalid" && field === "head") found.add("head-not-found");
    else if (code === "invalid" && field === "base") found.add("base-not-found");
  }
  // A draft refusal is read only when it is the whole answer: another reason beside it is that reason's to tell.
  if (found.size === 1) return [...found][0]!;
  return found.size === 0 ? "unknown" : [...found].find((reason) => reason !== "draft-unsupported") ?? "unknown";
}

export interface GitHubPullRequestDetails {
  number: number;
  url: string;
  state: "open" | "closed" | "merged";
  headBranch: string;
  baseBranch: string;
  headCommit: string;
  mergeCommit?: string;
  title: string;
  body: string;
}

export class GithubMergeRateLimitError extends Error {
  constructor(readonly retryAt: number) {
    if (!Number.isSafeInteger(retryAt) || retryAt < 1 || !Number.isFinite(new Date(retryAt).getTime())) {
      throw new Error("GitHub merge rate-limit retry time is invalid");
    }
    super("GitHub merge observation is rate limited");
    this.name = "GithubMergeRateLimitError";
  }
}

export interface GitHubPullRequestUpdate {
  title?: string;
  body?: string;
  state?: "open" | "closed";
}

export interface GitHubPullRequestChangedFile {
  filename: string;
  status: string;
  additions: number;
  deletions: number;
  patch?: string;
}

export interface GitHubWebhookRepositoryScope {
  installationId: number;
  repositoryId: number;
  fullName: string;
}

export interface GitHubRepositoryIdentity { repositoryId: number; fullName: string }

/** A repository the App can reach: its installation, and the owner as GitHub spells it. */
interface InstalledRepository {
  owner: string;
  name: string;
  installationId: number;
}

/**
 * Credentials from one GitHub App for repositories in every account it is installed on (#123).
 * Each repository's installation is looked up by its owner and cached for the process's
 * lifetime. There is no account allowlist: only administrators register repositories, and an
 * installation's token reaches only that installation's repositories.
 */
export class GitHubAppCredentialProvider {
  private readonly fetchImplementation: typeof fetch;
  private readonly now: () => number;
  private readonly installations = new Map<string, Promise<{ id: number; login: string }>>();
  private readonly readTokens = new Map<string, { token: Promise<string>; expiresAt: number }>();

  constructor(private readonly options: GitHubAppCredentialProviderOptions) {
    if (typeof options.appId === "string" && !GITHUB_APP_ID.test(options.appId)) throw new Error("GitHub App ID must be numeric");
    this.fetchImplementation = options.fetchImplementation ?? fetch;
    this.now = options.now ?? Date.now;
  }

  async resolve(
    credentialRef: string,
    repositoryUrl: string,
    access: RepositoryAccess = "clone",
  ): Promise<RepositoryCredential> {
    if (credentialRef !== this.options.credentialRef) return {};
    const token = await this.createInstallationToken(parseGitHubRepository(repositoryUrl), {
      contents: access === "push" ? "write" : "read",
    });
    return { username: "x-access-token", password: token };
  }

  /** Refuses, with CONFIG_INVALID, a repository of this App's credential that the App cannot reach. */
  async checkRepository(repository: { credentialRef: string; url: string }): Promise<void> {
    if (repository.credentialRef !== this.options.credentialRef) return;
    await this.installed(parseGitHubRepository(repository.url));
  }

  /** The credential reference projects name to use this App. */
  get credentialRef(): string {
    return this.options.credentialRef;
  }

  /**
   * Spec 065b: a repository the App is installed on, and its default branch, as GitHub says. Refuses a repository the App
   * cannot reach, so a project is never created on one it could not work on.
   */
  async repositoryDefaults(repositoryUrl: string): Promise<{ owner: string; name: string; defaultBranch: string }> {
    const installed = await this.installed(parseGitHubRepository(repositoryUrl));
    const token = await this.createInstallationToken(installed, { contents: "read" });
    const response = await this.fetchImplementation(
      `https://api.github.com/repos/${encodeURIComponent(installed.owner)}/${encodeURIComponent(installed.name)}`,
      { headers: githubHeaders(token), signal: AbortSignal.timeout(5_000), redirect: "error" },
    );
    if (response.status === 404) throw agentXError("NOT_FOUND", `the AgentX GitHub App cannot see ${installed.owner}/${installed.name}; install it on that repository`);
    if (!response.ok) throw agentXError("RUNTIME_UNAVAILABLE", `GitHub repository lookup failed with HTTP ${response.status}`);
    const body = await response.json() as { default_branch?: unknown };
    if (typeof body.default_branch !== "string" || body.default_branch === "") throw agentXError("RUNTIME_UNAVAILABLE", "GitHub returned no default branch");
    return { owner: installed.owner, name: installed.name, defaultBranch: body.default_branch };
  }

  /** Confirms a signed webhook's repository identity against the App's current installation and GitHub API. */
  async verifyWebhookRepository(repositoryUrl: string, scope: GitHubWebhookRepositoryScope): Promise<boolean> {
    const parsed = parseGitHubRepository(repositoryUrl);
    const expectedFullName = `${parsed.owner}/${parsed.name}`.toLowerCase();
    if (scope.fullName.toLowerCase() !== expectedFullName) return false;
    const installed = await this.installed(parsed);
    if (installed.installationId !== scope.installationId) return false;
    const token = await this.createInstallationToken(installed, { contents: "read" });
    const response = await this.fetchImplementation(
      `https://api.github.com/repos/${encodeURIComponent(installed.owner)}/${encodeURIComponent(installed.name)}`,
      { headers: githubHeaders(token), signal: AbortSignal.timeout(5_000), redirect: "error" },
    );
    if (response.status === 404) return false;
    if (!response.ok) throw agentXError("RUNTIME_UNAVAILABLE", `GitHub repository lookup failed with HTTP ${response.status}`);
    const body: unknown = await response.json();
    if (!body || typeof body !== "object" || Array.isArray(body)) {
      throw agentXError("RUNTIME_UNAVAILABLE", "GitHub returned an invalid repository response");
    }
    const record = body as Record<string, unknown>;
    return Number.isSafeInteger(record.id) && record.id === scope.repositoryId
      && typeof record.full_name === "string" && record.full_name.toLowerCase() === expectedFullName;
  }

  /** Reads the immutable GitHub numeric identity for a server-registered repository URL. */
  async getRepositoryIdentity(repositoryUrl: string): Promise<GitHubRepositoryIdentity | undefined> {
    const parsed = parseGitHubRepository(repositoryUrl);
    const expectedFullName = `${parsed.owner}/${parsed.name}`;
    const installed = await this.installed(parsed);
    const token = await this.createInstallationToken(installed, { contents: "read" });
    const response = await this.fetchImplementation(
      `https://api.github.com/repos/${encodeURIComponent(installed.owner)}/${encodeURIComponent(installed.name)}`,
      { headers: githubHeaders(token), signal: AbortSignal.timeout(5_000), redirect: "error" },
    );
    if (response.status === 404) return undefined;
    if (!response.ok) throw agentXError("RUNTIME_UNAVAILABLE", `GitHub repository lookup failed with HTTP ${response.status}`);
    const body: unknown = await response.json();
    if (!body || typeof body !== "object" || Array.isArray(body)) throw agentXError("RUNTIME_UNAVAILABLE", "GitHub returned an invalid repository response");
    const record = body as Record<string, unknown>;
    if (!Number.isSafeInteger(record.id) || typeof record.full_name !== "string" || record.full_name.toLowerCase() !== expectedFullName.toLowerCase()) {
      throw agentXError("RUNTIME_UNAVAILABLE", "GitHub returned an invalid repository identity");
    }
    return { repositoryId: record.id as number, fullName: record.full_name };
  }

  async issueCredentials(
    repository: { credentialRef: string; url: string },
    access: "read" | "write",
  ): Promise<{ owner: string; repo: string; token: string }> {
    if (repository.credentialRef !== this.options.credentialRef) {
      throw agentXError("FORBIDDEN", "repository does not use the configured GitHub App");
    }
    const parsed = parseGitHubRepository(repository.url);
    const installed = await this.installed(parsed);
    const token = await this.createInstallationToken(parsed, { issues: access });
    return { owner: installed.owner, repo: parsed.name, token };
  }

  async reconcilePullRequest(input: GitHubPullRequestInput): Promise<GitHubPullRequestResult> {
    const repository = await this.installed(parseGitHubRepository(input.repositoryUrl));
    // GitHub's pull-request endpoint needs to resolve the private repository's
    // base and head refs. Keep the token repository-scoped, but allow it to
    // read those refs in addition to creating the pull request.
    const token = await this.createInstallationToken(repository, {
      contents: "read",
      pull_requests: "write",
    });
    // The draft state is GitHub's, read from the pull request object on every path (created, or found again after a lost response or a broker retry), so the record and the
    // owner's message are always truthful (I2): a draft was refused when one was asked for and the pull request is not a draft.
    const finish = (found: FoundPullRequest, reconciled: boolean, refusedForSure = false): GitHubPullRequestResult => {
      const { isDraft, ...result } = found;
      return { ...result, reconciled, ...(refusedForSure || (input.draft === true && isDraft === false) ? { draftRefused: true as const } : {}) };
    };
    const existing = await this.findOpenPullRequest(repository, input, token);
    if (existing) return finish(existing, true);

    try {
      const create = (draft: boolean | undefined, body: string | undefined) => this.fetchImplementation(
        `https://api.github.com/repos/${encodeURIComponent(repository.owner)}/${encodeURIComponent(repository.name)}/pulls`,
        {
          method: "POST",
          headers: githubHeaders(token),
          body: JSON.stringify({
            title: input.title,
            head: input.headBranch,
            base: input.baseBranch,
            ...(body === undefined ? {} : { body }),
            ...(draft === undefined ? {} : { draft }),
          }),
        },
      );
      let response = await create(input.draft, input.body);
      if (response.ok) return finish(parsePullRequestWithDraft(await response.json(), repository), false);
      // INTG1: GitHub answers 422 to a draft on a private repository whose plan has no drafts. That answer, and only that, is retried once as a normal pull request with the
      // do-not-merge note; the result says so. Any other answer, and a second refusal, fails below.
      let refusal = response.status === 422 ? await pullRequestRefusalOf(response) : undefined;
      if (refusal === "draft-unsupported" && input.draft === true) {
        response = await create(undefined, pullRequestBodyWithDraftNote(input.body));
        if (response.ok) return finish(parsePullRequestWithDraft(await response.json(), repository), false, true);
        refusal = response.status === 422 ? await pullRequestRefusalOf(response) : undefined;
      }
      const afterFailure = await this.findOpenPullRequest(repository, input, token);
      if (afterFailure) return finish(afterFailure, true);
      throw agentXError("RUNTIME_UNAVAILABLE", `GitHub pull request creation failed with HTTP ${response.status}${refusal === undefined ? "" : `: ${PULL_REQUEST_REFUSAL_SENTENCES[refusal]}`}`);
    } catch (error) {
      if (isAgentXError(error)) throw error;
      const afterFailure = await this.findOpenPullRequest(repository, input, token);
      if (afterFailure) return finish(afterFailure, true);
      throw agentXError("RUNTIME_UNAVAILABLE", "GitHub pull request creation outcome is unknown");
    }
  }

  async getPullRequest(repositoryUrl: string, number: number): Promise<GitHubPullRequestDetails> {
    const repository = await this.installed(parseGitHubRepository(repositoryUrl));
    const token = await this.createInstallationToken(repository, {
      contents: "read",
      pull_requests: "read",
    });
    return this.getPullRequestWithToken(repository, number, token);
  }

  /** A bounded, stable merge-state read that cannot reuse or populate the singleton provider's caches. */
  async getPullRequestMergeObservation(
    repositoryUrl: string,
    number: number,
    budget: GithubMergeReadBudget,
  ): Promise<GitHubPullRequestDetails & { headTreeSha: string }> {
    const boundedFetch = (async (input: string | URL | Request, init?: RequestInit): Promise<Response> => {
      if (budget.signal.aborted) throw agentXError("RUNTIME_UNAVAILABLE", "GitHub merge observation was cancelled");
      budget.beforeRequest();
      if (budget.signal.aborted) throw agentXError("RUNTIME_UNAVAILABLE", "GitHub merge observation was cancelled");
      const signals = [budget.signal, init?.signal, AbortSignal.timeout(5_000)]
        .filter((signal): signal is AbortSignal => signal instanceof AbortSignal);
      const response = await this.fetchImplementation(input, { ...init, signal: AbortSignal.any(signals) });
      const retryAt = mergeRateLimitRetryAt(response, this.now());
      if (retryAt !== undefined) throw new GithubMergeRateLimitError(retryAt);
      return response;
    }) as typeof fetch;
    const scoped = new GitHubAppCredentialProvider({ ...this.options, fetchImplementation: boundedFetch, now: this.now });
    const repository = parseGitHubRepository(repositoryUrl);
    let installed: InstalledRepository;
    try {
      installed = await scoped.installed(repository);
    } catch (error) {
      if (error instanceof GithubMergeRateLimitError) throw error;
      if (isAgentXError(error) && error.code === "CONFIG_INVALID") {
        throw agentXError("RUNTIME_UNAVAILABLE", "GitHub merge observation installation is unavailable");
      }
      throw error;
    }
    const token = await scoped.createInstallationToken(installed, { contents: "read", pull_requests: "read" });
    const before = await scoped.getPullRequestWithToken(installed, number, token);
    assertMergePullRequestIdentity(before, number);
    const headTreeSha = await scoped.getCommitTreeWithToken(installed, before.headCommit, token);
    const after = await scoped.getPullRequestWithToken(installed, number, token);
    assertMergePullRequestIdentity(after, number);
    if (before.number !== after.number || before.url !== after.url || before.headCommit !== after.headCommit
      || before.state !== after.state || before.mergeCommit !== after.mergeCommit) {
      throw agentXError("RUNTIME_UNAVAILABLE", "GitHub merge observation changed during the read");
    }
    return { ...after, headTreeSha };
  }

  /** Reads a bounded PR diff summary for a code-aware, owner-approved feedback proposal. */
  async getPullRequestChangedFiles(repositoryUrl: string, number: number): Promise<GitHubPullRequestChangedFile[]> {
    const repository = await this.installed(parseGitHubRepository(repositoryUrl));
    const token = await this.createInstallationToken(repository, { contents: "read", pull_requests: "read" });
    const response = await this.fetchImplementation(
      `https://api.github.com/repos/${encodeURIComponent(repository.owner)}/${encodeURIComponent(repository.name)}/pulls/${number}/files?per_page=100`,
      { headers: { ...githubHeaders(token), accept: "application/vnd.github+json" }, signal: AbortSignal.timeout(8_000), redirect: "error" },
    );
    if (!response.ok) throw agentXError("RUNTIME_UNAVAILABLE", `GitHub pull request diff lookup failed with HTTP ${response.status}`);
    const body: unknown = await response.json();
    if (!Array.isArray(body)) throw agentXError("RUNTIME_UNAVAILABLE", "GitHub returned an invalid pull request diff");
    return body.slice(0, 100).flatMap((entry): GitHubPullRequestChangedFile[] => {
      if (!entry || typeof entry !== "object") return [];
      const file = entry as Record<string, unknown>;
      if (typeof file.filename !== "string" || file.filename.length > 500 || typeof file.status !== "string"
        || !Number.isSafeInteger(file.additions) || !Number.isSafeInteger(file.deletions)) return [];
      return [{ filename: file.filename, status: file.status, additions: file.additions as number, deletions: file.deletions as number,
        ...(typeof file.patch === "string" ? { patch: file.patch.slice(0, 3_000) } : {}) }];
    });
  }

  /**
   * One page (`perPage` files, at most 100) of a pull request's changed files, for the task diff screen. `more` is whether GitHub
   * says another page follows. A patch is kept whole here (the route decides what is too long to show); a file GitHub gave no
   * patch for (binary, or too large for GitHub) has none.
   */
  async getPullRequestFilesPage(repositoryUrl: string, number: number, page: number, perPage = 30): Promise<{ files: GitHubPullRequestChangedFile[]; more: boolean }> {
    if (!Number.isSafeInteger(number) || number < 1 || !Number.isSafeInteger(page) || page < 1 || page > 100 || !Number.isSafeInteger(perPage) || perPage < 1 || perPage > 100) {
      throw agentXError("CONFIG_INVALID", "the pull request diff page is invalid");
    }
    const repository = await this.installed(parseGitHubRepository(repositoryUrl));
    const token = await this.createInstallationToken(repository, { contents: "read", pull_requests: "read" });
    const response = await this.fetchImplementation(
      `https://api.github.com/repos/${encodeURIComponent(repository.owner)}/${encodeURIComponent(repository.name)}/pulls/${number}/files?per_page=${perPage}&page=${page}`,
      { headers: { ...githubHeaders(token), accept: "application/vnd.github+json" }, signal: AbortSignal.timeout(8_000), redirect: "error" },
    );
    if (!response.ok) throw agentXError("RUNTIME_UNAVAILABLE", `GitHub pull request diff lookup failed with HTTP ${response.status}`);
    const body: unknown = await response.json();
    if (!Array.isArray(body) || body.length > perPage) throw agentXError("RUNTIME_UNAVAILABLE", "GitHub returned an invalid pull request diff");
    const files = body.map((entry): GitHubPullRequestChangedFile => {
      const file = entry !== null && typeof entry === "object" ? entry as Record<string, unknown> : {};
      if (typeof file.filename !== "string" || file.filename.length === 0 || file.filename.length > 500 || typeof file.status !== "string"
        || !Number.isSafeInteger(file.additions) || !Number.isSafeInteger(file.deletions)) throw agentXError("RUNTIME_UNAVAILABLE", "GitHub returned an invalid pull request diff");
      return { filename: file.filename, status: file.status, additions: file.additions as number, deletions: file.deletions as number, ...(typeof file.patch === "string" ? { patch: file.patch } : {}) };
    });
    return { files, more: /<[^>]*>;\s*rel="next"/u.test(response.headers.get("link") ?? "") };
  }

  /** Current authoritative feedback, including thread resolution, read with a repository-scoped token. */
  async getPullRequestFeedback(repositoryUrl: string, number: number): Promise<GitHubPullRequestFeedback> {
    const repository = await this.installed(parseGitHubRepository(repositoryUrl));
    const token = await this.createInstallationToken(repository, { contents: "read", pull_requests: "read", issues: "read" });
    const prUrl = pullRequestUrl(repository, number);
    const before = await this.getPullRequestWithToken(repository, number, token);
    if (before.number !== number) throw feedbackReadError("PR scope mismatch");
    const root = prUrl.replace(/\/pulls\/\d+$/, "");
    const comments: GitHubFeedbackComment[] = [];
    for (const [path, kind] of [[`${prUrl}/reviews`, "REVIEW"], [`${prUrl}/comments`, "REVIEW_COMMENT"], [`${root}/issues/${number}/comments`, "DISCUSSION"]] as const) {
      for (const value of await this.feedbackPages(path, token)) {
        const record = feedbackRecord(value);
        if (kind === "REVIEW" && record.state === "PENDING") continue;
        const parsed = parseFeedbackComment(record, repository, number, kind);
        if (kind !== "REVIEW" || parsed.body.trim()) comments.push(parsed);
      }
    }
    // REST reviews expose submitted_at rather than the current edit time. Bind their bytes to GraphQL updatedAt.
    let reviewCursor: string | null = null;
    const reviewCursors = new Set<string>();
    const currentReviewIds = new Set<string>();
    do {
      const data = await this.feedbackGraphql(token, `query($owner:String!,$name:String!,$number:Int!,$cursor:String) {
        repository(owner:$owner,name:$name) { nameWithOwner pullRequest(number:$number) { number headRefOid
          reviews(first:100,after:$cursor) { nodes { fullDatabaseId updatedAt url body } pageInfo { hasNextPage endCursor } }
        } }
      }`, { owner: repository.owner, name: repository.name, number, cursor: reviewCursor });
      const repo = feedbackRecord(data.repository); const pr = feedbackRecord(repo.pullRequest);
      if (repo.nameWithOwner !== `${repository.owner}/${repository.name}` || pr.number !== number || pr.headRefOid !== before.headCommit) throw feedbackReadError("review scope or head changed");
      const connection = feedbackConnection(pr.reviews);
      for (const value of connection.nodes) {
        const review = feedbackRecord(value);
        const databaseId = feedbackDatabaseId(review.fullDatabaseId);
        // GraphQL sends fullDatabaseId as a string. A review with no usable ID cannot match a REST review, and the
        // "review set changed" check below refuses if a collected review is never matched.
        const id = databaseId === null ? null : `review:${databaseId}`;
        const comment = id === null ? undefined : comments.find(c => c.id === id && c.kind === "REVIEW");
        if (!id || !comment) continue; // Blank bodies and unpublished draft reviews were excluded by REST.
        if (currentReviewIds.has(id) || comment.url !== review.url || comment.body !== review.body
          || typeof review.updatedAt !== "string" || !Number.isFinite(Date.parse(review.updatedAt))) throw feedbackReadError("review changed during collection");
        currentReviewIds.add(id); comment.updatedAt = new Date(review.updatedAt).toISOString();
      }
      reviewCursor = nextFeedbackCursor(connection, reviewCursors);
    } while (reviewCursor !== null);
    if (comments.some(c => c.kind === "REVIEW" && !currentReviewIds.has(c.id))) throw feedbackReadError("review set changed during collection");
    const threads: GitHubFeedbackThread[] = [];
    let cursor: string | null = null;
    const seenCursors = new Set<string>();
    do {
      const data = await this.feedbackGraphql(token, `query($owner:String!,$name:String!,$number:Int!,$cursor:String) {
        repository(owner:$owner,name:$name) { nameWithOwner pullRequest(number:$number) { number headRefOid
          reviewThreads(first:100,after:$cursor) { nodes { ${FEEDBACK_THREAD_FIELDS} } pageInfo { hasNextPage endCursor } }
        } }
      }`, { owner: repository.owner, name: repository.name, number, cursor });
      const repo = feedbackRecord(data.repository);
      const pr = feedbackRecord(repo.pullRequest);
      if (repo.nameWithOwner !== `${repository.owner}/${repository.name}` || pr.number !== number || pr.headRefOid !== before.headCommit) throw feedbackReadError("PR scope or head changed");
      const connection = feedbackConnection(pr.reviewThreads);
      for (const value of connection.nodes) {
        const thread = feedbackRecord(value);
        validateFeedbackThread(thread, repository, number);
        const ids: string[] = [];
        let threadComments = feedbackConnection(thread.comments);
        const commentCursors = new Set<string>();
        for (;;) {
          for (const comment of threadComments.nodes) {
            const id = feedbackDatabaseId(feedbackRecord(comment).fullDatabaseId);
            if (id === null) throw feedbackReadError("invalid thread comment ID");
            ids.push(`review_comment:${id}`);
          }
          const next = nextFeedbackCursor(threadComments, commentCursors);
          if (next === null) break;
          const more = await this.feedbackGraphql(token, `query($threadId:ID!,$cursor:String) { node(id:$threadId) { ... on PullRequestReviewThread {
            id isResolved repository { nameWithOwner } pullRequest { number }
            comments(first:100,after:$cursor) { nodes { fullDatabaseId } pageInfo { hasNextPage endCursor } }
          } } }`, { threadId: thread.id, cursor: next });
          const node = feedbackRecord(more.node);
          validateFeedbackThread(node, repository, number);
          if (node.id !== thread.id || node.isResolved !== thread.isResolved) throw feedbackReadError("thread state changed during pagination");
          threadComments = feedbackConnection(node.comments);
        }
        threads.push({ id: thread.id as string, resolved: thread.isResolved as boolean, commentIds: ids });
      }
      cursor = nextFeedbackCursor(connection, seenCursors);
    } while (cursor !== null);
    const assignments = new Map<string, string>();
    const threadIds = new Set<string>();
    for (const thread of threads) {
      if (threadIds.has(thread.id)) throw feedbackReadError("duplicate thread in current state");
      threadIds.add(thread.id);
      for (const id of thread.commentIds) {
        if (assignments.has(id)) throw feedbackReadError("duplicate thread comment in current state");
        assignments.set(id, thread.id);
      }
    }
    const commentIds = new Set<string>();
    for (const comment of comments) {
      if (commentIds.has(comment.id)) throw feedbackReadError("duplicate comment in current state");
      commentIds.add(comment.id);
      if (comment.kind === "REVIEW_COMMENT") {
        const threadId = assignments.get(comment.id);
        if (!threadId) throw feedbackReadError("inline comment thread state is incomplete");
        comment.threadId = threadId;
      }
    }
    if ([...assignments.keys()].some(id => !commentIds.has(id))) throw feedbackReadError("thread and REST comment sets changed during collection");
    const after = await this.getPullRequestWithToken(repository, number, token);
    if (after.number !== number || after.headCommit !== before.headCommit || after.state !== before.state) throw feedbackReadError("PR head or state changed during collection");
    const headTreeSha = await this.getCommitTreeSha(repository, after.headCommit, token);
    const final = await this.getPullRequestWithToken(repository, number, token);
    if (final.number !== number || final.headCommit !== after.headCommit || final.state !== after.state) throw feedbackReadError("PR head or state changed during collection");
    return { pullRequest: { ...final, headTreeSha }, comments, threads };
  }

  /** The tree of a commit GitHub holds in the installed repository; throws when GitHub does not have that commit. */
  async getCommitTree(repositoryUrl: string, commitSha: string): Promise<string> {
    if (!/^[a-f0-9]{40}$/u.test(commitSha)) throw agentXError("CONFIG_INVALID", "commit identity is invalid");
    const repository = await this.installed(parseGitHubRepository(repositoryUrl));
    const token = await this.createInstallationToken(repository, { contents: "read" });
    return this.getCommitTreeSha(repository, commitSha, token);
  }

  /** Server-owned, complete-tree source capture for normal project setup discovery. */
  async captureE2ESourceSnapshot(repositoryUrl: string, ref: string): Promise<E2ESourceSnapshot> {
    if (!ref || ref.length > 255 || ref.startsWith("-") || /[\0\\~^:?*[\s]/.test(ref) || ref.split("/").some(part => part === "" || part === "." || part === "..")) {
      throw agentXError("CONFIG_INVALID", "repository ref is invalid");
    }
    const repository = await this.installed(parseGitHubRepository(repositoryUrl));
    const token = await this.readTokenFor(repository);
    const api = `https://api.github.com/repos/${encodeURIComponent(repository.owner)}/${encodeURIComponent(repository.name)}`;
    const headers = githubHeaders(token);
    const deadlineAt = this.now() + 60_000;
    const readJson = async (url: string, limit: number): Promise<Record<string, unknown>> => {
      const remaining = deadlineAt - this.now();
      if (remaining <= 0) throw agentXError("RUNTIME_UNAVAILABLE", "GitHub immutable source capture exceeded its shared deadline");
      const response = await this.fetchImplementation(url, { headers, signal: AbortSignal.timeout(Math.min(8_000, remaining)), redirect: "error" });
      if (!response.ok) { await response.body?.cancel(); throw agentXError("RUNTIME_UNAVAILABLE", `GitHub immutable source read failed with HTTP ${response.status}`); }
      const responseBody = response.body as unknown as ReadableStream<Uint8Array> | null;
      const reader = responseBody?.getReader();
      if (!reader) throw agentXError("RUNTIME_UNAVAILABLE", "GitHub immutable source response body is unavailable");
      const chunks: Uint8Array[] = []; let total = 0;
      try {
        for (;;) {
          const next = await reader.read();
          if (next.done) break;
          total += next.value.byteLength;
          if (total > limit) throw agentXError("RUNTIME_UNAVAILABLE", "GitHub immutable source metadata exceeded the response size limit");
          chunks.push(next.value);
        }
      } finally { await reader.cancel().catch(() => undefined); }
      const value: unknown = JSON.parse(Buffer.concat(chunks.map(chunk => Buffer.from(chunk))).toString("utf8"));
      if (!value || typeof value !== "object" || Array.isArray(value)) throw agentXError("RUNTIME_UNAVAILABLE", "GitHub returned invalid immutable source metadata");
      return value as Record<string, unknown>;
    };
    const commit = await readJson(`${api}/commits/${encodeURIComponent(ref)}`, 256 * 1024);
    const commitSha = commit.sha;
    const commitInfo = commit.commit && typeof commit.commit === "object" && !Array.isArray(commit.commit) ? commit.commit as Record<string, unknown> : undefined;
    const commitTree = commitInfo?.tree && typeof commitInfo.tree === "object" && !Array.isArray(commitInfo.tree) ? commitInfo.tree as Record<string, unknown> : undefined;
    const treeSha = commitTree?.sha;
    if (typeof commitSha !== "string" || !/^[a-f0-9]{40}$/u.test(commitSha) || typeof treeSha !== "string" || !/^[a-f0-9]{40}$/u.test(treeSha)) throw agentXError("RUNTIME_UNAVAILABLE", "GitHub returned an invalid immutable commit or tree identity");
    const treeBody = await readJson(`${api}/git/trees/${treeSha}?recursive=1`, 16 * 1024 * 1024);
    const entries = treeBody.tree;
    if (treeBody.sha !== treeSha || treeBody.truncated !== false || !Array.isArray(entries) || entries.length > 100_000) throw agentXError("RUNTIME_UNAVAILABLE", "GitHub returned a mismatched, incomplete or oversized immutable source tree");
    const paths: string[] = [];
    const selected: Array<{ path: string; sha: string; size: number }> = [];
    const seen = new Set<string>();
    for (const raw of entries) {
      if (!raw || typeof raw !== "object" || Array.isArray(raw)) throw agentXError("RUNTIME_UNAVAILABLE", "GitHub returned an invalid immutable tree entry");
      const entry = raw as Record<string, unknown>;
      const path = entry.path;
      if (typeof path !== "string" || path.length === 0 || path.length > 1024 || path.startsWith("/") || path.includes("\\") || path.includes("\0") || path.split("/").some(part => part === "" || part === "." || part === "..") || seen.has(path)) throw agentXError("RUNTIME_UNAVAILABLE", "GitHub returned an invalid or duplicate immutable tree path");
      seen.add(path); paths.push(path);
      const useful = isSafeE2ESourcePath(path) && /(?:^|\/)(?:package\.json|package-lock\.json|pnpm-lock\.yaml|yarn\.lock|Cargo\.toml|Cargo\.lock|go\.mod|go\.sum|pyproject\.toml|requirements\.txt|AndroidManifest\.xml|build\.gradle(?:\.kts)?|settings\.gradle(?:\.kts)?|project\.pbxproj|Info\.plist|.*\.(?:js|mjs|cjs|ts|tsx|jsx|json|swift|kt|kts|plist|gradle|md|toml|ya?ml))$/i.test(path);
      if (!useful || entry.type !== "blob") continue;
      if (entry.mode !== "100644" && entry.mode !== "100755") throw agentXError("RUNTIME_UNAVAILABLE", "selected immutable source path has an unsupported Git mode");
      if (typeof entry.sha !== "string" || !/^[a-f0-9]{40}$/u.test(entry.sha) || typeof entry.size !== "number" || !Number.isSafeInteger(entry.size) || entry.size < 0 || entry.size > 512 * 1024) throw agentXError("RUNTIME_UNAVAILABLE", "selected immutable source blob exceeds supported bounds");
      selected.push({ path, sha: entry.sha, size: entry.size });
    }
    if (selected.length > 512) throw agentXError("RUNTIME_UNAVAILABLE", "selected immutable source set exceeds 512 files");
    const sources: E2ESourceSnapshot["sources"][number][] = [];
    let total = 0;
    for (const entry of selected) {
      const blob = await readJson(`${api}/git/blobs/${entry.sha}`, 768 * 1024);
      if (blob.sha !== entry.sha || blob.encoding !== "base64" || blob.size !== entry.size || typeof blob.content !== "string") throw agentXError("RUNTIME_UNAVAILABLE", "GitHub returned mismatched immutable source blob data");
      const encoded = blob.content.replace(/[\r\n\t ]/g, "");
      if (!/^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/u.test(encoded)) throw agentXError("RUNTIME_UNAVAILABLE", "GitHub returned malformed immutable source bytes");
      const bytes = Buffer.from(encoded, "base64");
      const actualGitSha = createHash("sha1").update(Buffer.from(`blob ${bytes.byteLength}\0`)).update(bytes).digest("hex");
      if (bytes.byteLength !== entry.size || actualGitSha !== entry.sha) throw agentXError("RUNTIME_UNAVAILABLE", "GitHub source bytes do not match immutable Git blob identity");
      total += bytes.byteLength;
      if (total > 4 * 1024 * 1024) throw agentXError("RUNTIME_UNAVAILABLE", "selected immutable source set exceeds 4 MiB");
      sources.push({ path: entry.path, sha256: createHash("sha256").update(bytes).digest("hex"), bytes, kind: "blob" });
    }
    const fullName = `${repository.owner}/${repository.name}`;
    const candidate = createCandidateManifest([{ repositoryId: fullName, commitSha, treeSha }]);
    return { candidate, commitSha, treeSha, treeComplete: true, treePaths: paths, sources };
  }

  /**
   * A file's text as GitHub holds it at a commit; undefined when the file is not there.
   * With `untilLine` the body is read as a stream and the read stops after that many newline-ended lines (the text through that line is returned);
   * a file that ends sooner comes back whole. Throws when GitHub cannot answer or 20 MB arrive before the wanted line (or without one).
   * `timeoutMs` (default 8,000) is how long the request may take, for a caller that has more time to give.
   */
  async getFileAtCommit(repositoryUrl: string, path: string, commitSha: string, options?: { untilLine?: number; timeoutMs?: number }): Promise<string | undefined> {
    if (!/^[a-f0-9]{40}$/u.test(commitSha)) throw agentXError("CONFIG_INVALID", "commit identity is invalid");
    const segments = path.split("/");
    if (path.length === 0 || path.length > 512 || path.includes("\\") || segments.some((segment) => segment === "" || segment === "." || segment === "..")) {
      throw agentXError("CONFIG_INVALID", "file path is invalid");
    }
    const untilLine = options?.untilLine;
    const repository = await this.installed(parseGitHubRepository(repositoryUrl));
    const token = await this.readTokenFor(repository);
    const response = await this.fetchImplementation(
      `https://api.github.com/repos/${encodeURIComponent(repository.owner)}/${encodeURIComponent(repository.name)}/contents/${segments.map(encodeURIComponent).join("/")}?ref=${commitSha}`,
      { headers: { ...githubHeaders(token), accept: "application/vnd.github.raw+json" }, signal: AbortSignal.timeout(options?.timeoutMs ?? FILE_AT_COMMIT_TIMEOUT_MS), redirect: "error" },
    );
    if (response.status === 404) { await response.body?.cancel(); return undefined; }
    if (!response.ok) {
      await response.body?.cancel();
      throw agentXError("RUNTIME_UNAVAILABLE", `GitHub file lookup failed with HTTP ${response.status}`);
    }
    // A directory answers with a JSON listing even for the raw media type; it is not a file, so it is not there.
    if (response.headers.get("content-type")?.toLowerCase().startsWith("application/json") === true) { await response.body?.cancel(); return undefined; }
    const tooLarge = () => agentXError("RUNTIME_UNAVAILABLE", untilLine === undefined ? "file too large" : "file too large to read up to the cited line");
    // Without a last line the whole file is wanted, so a declared size over the cap is refused before any byte is read.
    if (untilLine === undefined && Number(response.headers.get("content-length")) > FILE_AT_COMMIT_MAX_BYTES) {
      await response.body?.cancel();
      throw tooLarge();
    }
    if (response.body === null) return "";
    const reader = response.body.getReader();
    const chunks: Uint8Array[] = [];
    let total = 0;
    let lines = 0;
    for (;;) {
      const result = await reader.read();
      if (result.done) break;
      let value = result.value as Uint8Array;
      let reached = false;
      if (untilLine !== undefined) {
        // Find the newline that ends the wanted line; the rest of this chunk is not needed.
        let from = 0;
        for (let end = value.indexOf(10, from); end !== -1; end = value.indexOf(10, from)) {
          lines += 1;
          from = end + 1;
          if (lines >= untilLine) { value = value.subarray(0, from); reached = true; break; }
        }
      }
      total += value.byteLength;
      if (total > FILE_AT_COMMIT_MAX_BYTES) {
        await reader.cancel();
        throw tooLarge();
      }
      chunks.push(value);
      if (reached) { await reader.cancel().catch(() => undefined); break; }
    }
    return new TextDecoder().decode(Buffer.concat(chunks));
  }

  /** A contents-read token for reading files: reused for 5 minutes per repository, so a run of file reads mints one. */
  private readTokenFor(repository: InstalledRepository): Promise<string> {
    const key = `${repository.owner.toLowerCase()}/${repository.name.toLowerCase()}:contents=read`;
    const cached = this.readTokens.get(key);
    if (cached !== undefined && cached.expiresAt > this.now()) return cached.token;
    const token = this.createInstallationToken(repository, { contents: "read" });
    this.readTokens.set(key, { token, expiresAt: this.now() + READ_TOKEN_REUSE_MS });
    token.catch(() => { if (this.readTokens.get(key)?.token === token) this.readTokens.delete(key); });
    return token;
  }

  /** The parents of a commit GitHub holds in the installed repository; throws when GitHub does not have that commit. */
  async getCommitParents(repositoryUrl: string, commitSha: string): Promise<string[]> {
    if (!/^[a-f0-9]{40}$/u.test(commitSha)) throw agentXError("CONFIG_INVALID", "commit identity is invalid");
    const repository = await this.installed(parseGitHubRepository(repositoryUrl));
    const token = await this.createInstallationToken(repository, { contents: "read" });
    const value = await this.getCommitObject(repository, commitSha, token);
    if (!Array.isArray(value.parents)) throw feedbackReadError("invalid commit parents");
    return value.parents.map((parent) => {
      const sha = feedbackRecord(parent).sha;
      if (typeof sha !== "string" || !/^[a-f0-9]{40}$/u.test(sha)) throw feedbackReadError("invalid commit parent identity");
      return sha;
    });
  }

  /** The commit a branch points at now, as GitHub says; throws when the branch does not exist. */
  async getBranchHead(repositoryUrl: string, branch: string): Promise<string> {
    if (!/^agentx\/[0-9a-f-]{36}$/iu.test(branch)) throw agentXError("CONFIG_INVALID", "branch name is invalid");
    const repository = await this.installed(parseGitHubRepository(repositoryUrl));
    const token = await this.createInstallationToken(repository, { contents: "read" });
    const response = await this.fetchImplementation(
      `https://api.github.com/repos/${encodeURIComponent(repository.owner)}/${encodeURIComponent(repository.name)}/git/ref/heads/${branch}`,
      { headers: githubHeaders(token), signal: AbortSignal.timeout(8_000), redirect: "error" },
    );
    if (!response.ok) throw agentXError("RUNTIME_UNAVAILABLE", `GitHub branch lookup failed with HTTP ${response.status}`);
    const value = feedbackRecord(await response.json());
    const target = feedbackRecord(value.object);
    if (value.ref !== `refs/heads/${branch}` || target.type !== "commit" || typeof target.sha !== "string" || !/^[a-f0-9]{40}$/u.test(target.sha)) {
      throw agentXError("RUNTIME_UNAVAILABLE", "GitHub returned an invalid branch reference");
    }
    return target.sha;
  }

  /** GitHub's immutable tree object identifies code content independently of publication commit metadata. */
  private async getCommitTreeSha(repository: InstalledRepository, commitSha: string, token: string): Promise<string> {
    const value = await this.getCommitObject(repository, commitSha, token);
    const tree = feedbackRecord(value.tree);
    if (typeof tree.sha !== "string" || !/^[a-f0-9]{40}$/u.test(tree.sha)) throw feedbackReadError("invalid PR head tree identity");
    return tree.sha;
  }

  /** GitHub's Git commit object (its tree and parents). */
  private async getCommitObject(repository: InstalledRepository, commitSha: string, token: string): Promise<Record<string, unknown>> {
    const response = await this.fetchImplementation(
      `https://api.github.com/repos/${encodeURIComponent(repository.owner)}/${encodeURIComponent(repository.name)}/git/commits/${commitSha}`,
      { headers: githubHeaders(token), signal: AbortSignal.timeout(8_000), redirect: "error" },
    );
    if (!response.ok) throw feedbackReadError(`head commit lookup HTTP ${response.status}`);
    return feedbackRecord(await response.json());
  }

  private async feedbackPages(path: string, token: string): Promise<unknown[]> {
    const values: unknown[] = [];
    let next: string | undefined = `${path}?per_page=100&page=1`;
    const seen = new Set<string>();
    while (next) {
      if (seen.has(next)) throw feedbackReadError("pagination did not advance");
      seen.add(next);
      const response = await this.fetchImplementation(next, { headers: githubHeaders(token), redirect: "error", signal: AbortSignal.timeout(8_000) });
      if (!response.ok) throw feedbackReadError(`comment lookup HTTP ${response.status}`);
      const page: unknown = await response.json();
      if (!Array.isArray(page)) throw feedbackReadError("invalid comment page");
      for (const value of page as unknown[]) values.push(value);
      const link = response.headers.get("link");
      const linked = link?.split(",").map(part => /^\s*<([^>]+)>;\s*rel="next"\s*$/.exec(part)).find(match => match)?.[1];
      if (linked) {
        const url = new URL(linked);
        if (`${url.origin}${url.pathname}` !== path || url.username || url.password || url.hash
          || [...url.searchParams.keys()].some(key => key !== "per_page" && key !== "page")
          || url.searchParams.get("per_page") !== "100" || !/^[1-9][0-9]*$/.test(url.searchParams.get("page") ?? "")) throw feedbackReadError("pagination scope mismatch");
        next = url.href;
      } else if (!link && page.length === 100) {
        const url: URL = new URL(next); url.searchParams.set("page", String(Number(url.searchParams.get("page")) + 1)); next = url.href;
      } else next = undefined;
    }
    return values;
  }

  private async feedbackGraphql(token: string, query: string, variables: Record<string, unknown>): Promise<Record<string, unknown>> {
    const response = await this.fetchImplementation("https://api.github.com/graphql", {
      method: "POST", headers: githubHeaders(token), body: JSON.stringify({ query, variables }), redirect: "error", signal: AbortSignal.timeout(8_000),
    });
    if (!response.ok) throw feedbackReadError(`thread lookup HTTP ${response.status}`);
    const body = feedbackRecord(await response.json());
    if (body.errors !== undefined) throw feedbackReadError("thread lookup incomplete");
    return feedbackRecord(body.data);
  }

  async updatePullRequest(
    repositoryUrl: string,
    number: number,
    update: GitHubPullRequestUpdate,
  ): Promise<GitHubPullRequestDetails> {
    if (update.title === undefined && update.body === undefined && update.state === undefined) {
      throw agentXError("CONFIG_INVALID", "pull request update is empty");
    }
    const repository = await this.installed(parseGitHubRepository(repositoryUrl));
    const token = await this.createInstallationToken(repository, {
      contents: "read",
      pull_requests: "write",
    });
    try {
      const response = await this.fetchImplementation(
        pullRequestUrl(repository, number),
        {
          method: "PATCH",
          headers: githubHeaders(token),
          body: JSON.stringify(update),
        },
      );
      if (response.ok) {
        return parsePullRequestDetails(await response.json(), repository);
      }
      const reconciled = await this.getPullRequestWithToken(repository, number, token);
      if (matchesUpdate(reconciled, update)) return reconciled;
      throw agentXError("RUNTIME_UNAVAILABLE", `GitHub pull request update failed with HTTP ${response.status}`);
    } catch (error) {
      if (isAgentXError(error)) throw error;
      const reconciled = await this.getPullRequestWithToken(repository, number, token).catch(() => undefined);
      if (reconciled && matchesUpdate(reconciled, update)) return reconciled;
      throw agentXError("RUNTIME_UNAVAILABLE", "GitHub pull request update outcome is unknown");
    }
  }

  private async getPullRequestWithToken(
    repository: InstalledRepository,
    number: number,
    token: string,
  ): Promise<GitHubPullRequestDetails> {
    const response = await this.fetchImplementation(
      pullRequestUrl(repository, number),
      { headers: githubHeaders(token) },
    );
    if (!response.ok) {
      throw agentXError("RUNTIME_UNAVAILABLE", `GitHub pull request lookup failed with HTTP ${response.status}`);
    }
    return parsePullRequestDetails(await response.json(), repository);
  }

  private async getCommitTreeWithToken(
    repository: InstalledRepository,
    commit: string,
    token: string,
  ): Promise<string> {
    const response = await this.fetchImplementation(
      `https://api.github.com/repos/${encodeURIComponent(repository.owner)}/${encodeURIComponent(repository.name)}/git/commits/${commit}`,
      { headers: githubHeaders(token) },
    );
    if (!response.ok) throw agentXError("RUNTIME_UNAVAILABLE", `GitHub commit tree lookup failed with HTTP ${response.status}`);
    const value: unknown = await response.json();
    const record = value && typeof value === "object" && !Array.isArray(value) ? value as Record<string, unknown> : undefined;
    const tree = record?.tree;
    const treeSha = tree && typeof tree === "object" && !Array.isArray(tree) ? (tree as Record<string, unknown>).sha : undefined;
    if (record?.sha !== commit || typeof treeSha !== "string" || !/^[a-f0-9]{40}$/.test(treeSha)) {
      throw agentXError("RUNTIME_UNAVAILABLE", "GitHub returned an invalid commit tree response");
    }
    return treeSha;
  }

  /** The repository's installation, cached by owner; a failed lookup is not cached. */
  private async installed(repository: { owner: string; name: string }): Promise<InstalledRepository> {
    const key = repository.owner.toLowerCase();
    let installation = this.installations.get(key);
    if (installation === undefined) {
      installation = this.lookUpInstallation(repository);
      this.installations.set(key, installation);
      const pending = installation;
      pending.catch(() => {
        if (this.installations.get(key) === pending) this.installations.delete(key);
      });
    }
    const { id, login } = await installation;
    return { owner: login, name: repository.name, installationId: id };
  }

  private async lookUpInstallation(repository: { owner: string; name: string }): Promise<{ id: number; login: string }> {
    const response = await this.fetchImplementation(
      `https://api.github.com/repos/${encodeURIComponent(repository.owner)}/${encodeURIComponent(repository.name)}/installation`,
      { headers: await this.appHeaders(), signal: AbortSignal.timeout(5_000), redirect: "error" },
    );
    if (response.status === 404) {
      throw agentXError(
        "CONFIG_INVALID",
        `the GitHub App cannot access ${repository.owner}/${repository.name}; install it on ${repository.owner} with access to that repository`,
      );
    }
    if (!response.ok) {
      throw agentXError("RUNTIME_UNAVAILABLE", `GitHub App installation lookup failed with HTTP ${response.status}`);
    }
    const body: unknown = await response.json();
    const id = body && typeof body === "object" && "id" in body ? body.id : undefined;
    const account = body && typeof body === "object" && "account" in body ? body.account : undefined;
    const login = account && typeof account === "object" && "login" in account ? account.login : undefined;
    if (!Number.isSafeInteger(id) || (id as number) < 1 || typeof login !== "string" || login.toLowerCase() !== repository.owner.toLowerCase()) {
      throw agentXError("RUNTIME_UNAVAILABLE", "GitHub returned an invalid installation response");
    }
    return { id: id as number, login };
  }

  /**
   * Spec 065b: the accounts the App is installed on and the repositories each lets it reach (the first 100 of each), read
   * with a metadata-only token per installation. A suspended installation is listed with no repositories.
   */
  async installedRepositories(): Promise<ClientRepositoriesResponse["installations"]> {
    const response = await this.fetchImplementation("https://api.github.com/app/installations?per_page=100", {
      headers: await this.appHeaders(), signal: AbortSignal.timeout(5_000), redirect: "error",
    });
    if (!response.ok) throw agentXError("RUNTIME_UNAVAILABLE", `GitHub App installations lookup failed with HTTP ${response.status}`);
    const installations = InstallationsSchema.safeParse(await response.json());
    if (!installations.success) throw agentXError("RUNTIME_UNAVAILABLE", "GitHub returned an invalid installations response");
    return Promise.all(installations.data.map(async (installation) => {
      const status = installation.suspended_at ? "suspended" as const : "active" as const;
      const listed = { installationId: installation.id, accountLogin: installation.account.login, accountType: installation.account.type, repositorySelection: installation.repository_selection, status };
      if (status === "suspended") return { ...listed, repositories: [] };
      const tokenResponse = await this.fetchImplementation(`https://api.github.com/app/installations/${installation.id}/access_tokens`, {
        method: "POST", headers: await this.appHeaders(), body: JSON.stringify({ permissions: { metadata: "read" } }), signal: AbortSignal.timeout(5_000), redirect: "error",
      });
      const token = tokenResponse.ok ? (await tokenResponse.json() as { token?: unknown }).token : undefined;
      if (typeof token !== "string") throw agentXError("RUNTIME_UNAVAILABLE", `GitHub App installation token request failed with HTTP ${tokenResponse.status}`);
      const reposResponse = await this.fetchImplementation("https://api.github.com/installation/repositories?per_page=100", {
        headers: githubHeaders(token), signal: AbortSignal.timeout(5_000), redirect: "error",
      });
      const repositories = reposResponse.ok ? InstallationRepositoriesSchema.safeParse(await reposResponse.json()) : undefined;
      if (repositories?.success !== true) throw agentXError("RUNTIME_UNAVAILABLE", `GitHub repository list failed with HTTP ${reposResponse.status}`);
      return { ...listed, repositories: repositories.data.repositories.map((repository) => ({ fullName: repository.full_name, githubRepositoryId: repository.id, private: repository.private, defaultBranch: repository.default_branch })) };
    }));
  }

  /** Spec 025 A13: how many accounts the App is installed on (the first 100), for the health route. */
  async installationCount(): Promise<number> {
    const response = await this.fetchImplementation("https://api.github.com/app/installations?per_page=100", {
      headers: await this.appHeaders(), signal: AbortSignal.timeout(5_000), redirect: "error",
    });
    if (!response.ok) throw agentXError("RUNTIME_UNAVAILABLE", `GitHub App installations lookup failed with HTTP ${response.status}`);
    const body: unknown = await response.json();
    if (!Array.isArray(body)) throw agentXError("RUNTIME_UNAVAILABLE", "GitHub returned an invalid installations response");
    return body.length;
  }

  private async appHeaders(): Promise<Record<string, string>> {
    const appId = typeof this.options.appId === "string" ? this.options.appId : await this.options.appId();
    if (!GITHUB_APP_ID.test(appId)) throw agentXError("RUNTIME_UNAVAILABLE", "GitHub App ID must be numeric");
    const privateKey = await this.options.getPrivateKey();
    const jwt = createGitHubAppJwt(appId, privateKey, this.now());
    return {
      accept: "application/vnd.github+json",
      authorization: `Bearer ${jwt}`,
      "content-type": "application/json",
      "user-agent": "agentx-control-plane",
      "x-github-api-version": "2022-11-28",
    };
  }

  /**
   * A token for one repository. When the cached installation is gone (the App was uninstalled
   * and installed again, which gives it a new ID), the installation is looked up once more.
   */
  private async createInstallationToken(
    repository: { owner: string; name: string },
    permissions: Record<string, "read" | "write">,
    retried = false,
  ): Promise<string> {
    const installed = await this.installed(repository);
    const response = await this.fetchImplementation(
      `https://api.github.com/app/installations/${installed.installationId}/access_tokens`,
      {
        method: "POST",
        headers: await this.appHeaders(),
        body: JSON.stringify({
          repositories: [installed.name],
          permissions,
        }),
        signal: AbortSignal.timeout(5_000),
        redirect: "error",
      },
    );
    if (response.status === 404 && !retried) {
      this.installations.delete(installed.owner.toLowerCase());
      return this.createInstallationToken(repository, permissions, true);
    }
    if (!response.ok) {
      throw agentXError(
        "RUNTIME_UNAVAILABLE",
        `GitHub App installation token request failed with HTTP ${response.status}`,
      );
    }
    const body: unknown = await response.json();
    if (!body || typeof body !== "object" || !("token" in body) || typeof body.token !== "string") {
      throw agentXError("RUNTIME_UNAVAILABLE", "GitHub returned an invalid installation token response");
    }
    return body.token;
  }

  private async findOpenPullRequest(
    repository: InstalledRepository,
    input: GitHubPullRequestInput,
    token: string,
  ): Promise<FoundPullRequest | undefined> {
    const query = new URLSearchParams({
      state: "open",
      head: `${repository.owner}:${input.headBranch}`,
      base: input.baseBranch,
      per_page: "2",
    });
    const response = await this.fetchImplementation(
      `https://api.github.com/repos/${encodeURIComponent(repository.owner)}/${encodeURIComponent(repository.name)}/pulls?${query.toString()}`,
      { headers: githubHeaders(token) },
    );
    if (!response.ok) {
      throw agentXError("RUNTIME_UNAVAILABLE", `GitHub pull request lookup failed with HTTP ${response.status}`);
    }
    const value: unknown = await response.json();
    if (!Array.isArray(value)) {
      throw agentXError("RUNTIME_UNAVAILABLE", "GitHub returned an invalid pull request response");
    }
    if (value.length === 0) return undefined;
    return parsePullRequestWithDraft(value[0], repository);
  }
}

export interface GitHubFeedbackComment {
  id: string; threadId?: string; kind: "REVIEW" | "REVIEW_COMMENT" | "DISCUSSION";
  url: string; author: string; updatedAt: string; body: string; path?: string; line?: number;
}
export interface GitHubFeedbackThread { id: string; resolved: boolean; commentIds: string[] }
export interface GitHubPullRequestFeedback {
  pullRequest: GitHubPullRequestDetails & { headTreeSha: string }; comments: GitHubFeedbackComment[]; threads: GitHubFeedbackThread[];
}
const FEEDBACK_THREAD_FIELDS = `id isResolved repository { nameWithOwner } pullRequest { number }
  comments(first:100) { nodes { fullDatabaseId } pageInfo { hasNextPage endCursor } }`;
/** A GitHub database ID: a positive-integer string (GraphQL BigInt) or a safe-integer number. Null when neither. */
function feedbackDatabaseId(value: unknown): string | null {
  if (typeof value !== "string" && typeof value !== "number") return null;
  if (typeof value === "number" && !Number.isSafeInteger(value)) return null;
  const text = String(value);
  return /^[1-9][0-9]*$/.test(text) ? text : null;
}
function feedbackReadError(reason: string): AgentXError { return agentXError("RUNTIME_UNAVAILABLE", `GitHub feedback read refused: ${reason}`); }
function feedbackRecord(value: unknown): Record<string, unknown> {
  if (!value || typeof value !== "object" || Array.isArray(value)) throw feedbackReadError("invalid record");
  return value as Record<string, unknown>;
}
function feedbackConnection(value: unknown): { nodes: unknown[]; pageInfo: { hasNextPage: boolean; endCursor: string | null } } {
  const record = feedbackRecord(value); const info = feedbackRecord(record.pageInfo);
  if (!Array.isArray(record.nodes) || typeof info.hasNextPage !== "boolean" || (info.endCursor !== null && typeof info.endCursor !== "string")) throw feedbackReadError("invalid pagination state");
  return { nodes: record.nodes, pageInfo: { hasNextPage: info.hasNextPage, endCursor: info.endCursor } };
}
function nextFeedbackCursor(connection: ReturnType<typeof feedbackConnection>, seen: Set<string>): string | null {
  if (!connection.pageInfo.hasNextPage) return null;
  const cursor = connection.pageInfo.endCursor;
  if (!cursor || seen.has(cursor)) throw feedbackReadError("pagination did not advance");
  seen.add(cursor); return cursor;
}
function validateFeedbackThread(thread: Record<string, unknown>, repo: InstalledRepository, number: number): void {
  if (typeof thread.id !== "string" || !thread.id || typeof thread.isResolved !== "boolean"
    || feedbackRecord(thread.repository).nameWithOwner !== `${repo.owner}/${repo.name}`
    || feedbackRecord(thread.pullRequest).number !== number) throw feedbackReadError("thread scope mismatch");
}
function parseFeedbackComment(record: Record<string, unknown>, repository: InstalledRepository, number: number, kind: GitHubFeedbackComment["kind"]): GitHubFeedbackComment {
  const prefix = kind === "REVIEW" ? "review" : kind === "REVIEW_COMMENT" ? "review_comment" : "discussion";
  const anchor = kind === "REVIEW" ? "pullrequestreview-" : kind === "REVIEW_COMMENT" ? "discussion_r" : "issuecomment-";
  if (typeof record.id !== "number" || !Number.isSafeInteger(record.id) || record.id < 1) throw feedbackReadError("invalid comment ID");
  const commentId = record.id;
  const expected = `https://github.com/${repository.owner}/${repository.name}/pull/${number}#${anchor}${commentId}`;
  const api = `https://api.github.com/repos/${repository.owner}/${repository.name}`;
  const user = feedbackRecord(record.user);
  const timestamp = record.updated_at ?? record.submitted_at;
  if (record.html_url !== expected || (kind === "REVIEW_COMMENT" && record.pull_request_url !== `${api}/pulls/${number}`)
    || (kind === "DISCUSSION" && record.issue_url !== `${api}/issues/${number}`)) throw feedbackReadError("comment scope mismatch: non-canonical URL");
  if ((record.body !== null && typeof record.body !== "string") || typeof user.login !== "string" || !user.login || user.login.length > 100
    || typeof timestamp !== "string" || !/^\d{4}-\d\d-\d\dT/.test(timestamp) || !Number.isFinite(Date.parse(timestamp))) throw feedbackReadError("invalid comment content");
  if (record.path !== undefined && (typeof record.path !== "string" || record.path.length > 1024)) throw feedbackReadError("invalid comment path");
  if (record.line !== undefined && record.line !== null && (!Number.isSafeInteger(record.line) || (record.line as number) < 1)) throw feedbackReadError("invalid comment line");
  return { id: `${prefix}:${commentId}`, kind, url: expected, author: user.login, updatedAt: new Date(timestamp).toISOString(), body: (record.body) ?? "",
    ...(kind === "REVIEW_COMMENT" && typeof record.path === "string" ? { path: record.path } : {}),
    ...(kind === "REVIEW_COMMENT" && typeof record.line === "number" ? { line: record.line } : {}) };
}

function pullRequestUrl(repository: InstalledRepository, number: number): string {
  if (!Number.isInteger(number) || number < 1) throw agentXError("CONFIG_INVALID", "pull request number is invalid");
  return `https://api.github.com/repos/${encodeURIComponent(repository.owner)}/${encodeURIComponent(repository.name)}/pulls/${number}`;
}

function matchesUpdate(details: GitHubPullRequestDetails, update: GitHubPullRequestUpdate): boolean {
  return (update.title === undefined || details.title === update.title) &&
    (update.body === undefined || details.body === update.body) &&
    (update.state === undefined || details.state === update.state);
}

function githubHeaders(token: string): Record<string, string> {
  return {
    accept: "application/vnd.github+json",
    authorization: `Bearer ${token}`,
    "content-type": "application/json",
    "user-agent": "agentx-control-plane",
    "x-github-api-version": "2022-11-28",
  };
}

function safeFutureMilliseconds(value: number, now: number): number | undefined {
  return Number.isSafeInteger(value) && value > now && Number.isFinite(new Date(value).getTime()) ? value : undefined;
}

function mergeRateLimitRetryAt(response: Response, now: number): number | undefined {
  if (response.status !== 429 && response.status !== 403) return undefined;
  const candidates: number[] = [];
  const retryAfter = response.headers.get("retry-after");
  if (retryAfter !== null) {
    const seconds = /^[0-9]+$/.test(retryAfter.trim()) ? Number(retryAfter.trim()) : Number.NaN;
    const relative = safeFutureMilliseconds(now + seconds * 1_000, now);
    const absolute = safeFutureMilliseconds(Date.parse(retryAfter), now);
    if (relative !== undefined) candidates.push(relative);
    else if (absolute !== undefined) candidates.push(absolute);
  }
  const exhausted = response.headers.get("x-ratelimit-remaining")?.trim() === "0";
  if (exhausted) {
    const resetSeconds = response.headers.get("x-ratelimit-reset");
    const reset = resetSeconds !== null && /^[0-9]+$/.test(resetSeconds.trim())
      ? safeFutureMilliseconds(Number(resetSeconds.trim()) * 1_000, now) : undefined;
    if (reset !== undefined) candidates.push(reset);
  }
  if (response.status === 403 && candidates.length === 0 && !exhausted) return undefined;
  return candidates.length > 0 ? Math.max(...candidates) : safeFutureMilliseconds(now + 5 * 60_000, now);
}

function assertMergePullRequestIdentity(details: GitHubPullRequestDetails, expectedNumber: number): void {
  if (details.number !== expectedNumber || !/^[a-f0-9]{40}$/.test(details.headCommit)
    || (details.mergeCommit !== undefined && !/^[a-f0-9]{40}$/.test(details.mergeCommit))) {
    throw agentXError("RUNTIME_UNAVAILABLE", "GitHub returned an invalid merge observation identity");
  }
}

function parsePullRequest(
  value: unknown,
  repository: InstalledRepository,
): Omit<GitHubPullRequestResult, "reconciled"> {
  if (!value || typeof value !== "object" || Array.isArray(value)) {
    throw agentXError("RUNTIME_UNAVAILABLE", "GitHub returned an invalid pull request response");
  }
  const candidate = value as Record<string, unknown>;
  if (!Number.isInteger(candidate.number) || (candidate.number as number) < 1 || typeof candidate.html_url !== "string") {
    throw agentXError("RUNTIME_UNAVAILABLE", "GitHub returned an invalid pull request response");
  }
  const expected = `https://github.com/${repository.owner}/${repository.name}/pull/${String(candidate.number)}`;
  if (candidate.html_url !== expected) {
    throw agentXError("RUNTIME_UNAVAILABLE", "GitHub returned a non-canonical pull request URL");
  }
  return { number: candidate.number as number, url: candidate.html_url };
}

/** A pull request as the reconcile paths read it: the result without `reconciled`, and GitHub's own `draft` flag when it gives one. */
type FoundPullRequest = Omit<GitHubPullRequestResult, "reconciled" | "draftRefused"> & { isDraft?: boolean };
function parsePullRequestWithDraft(value: unknown, repository: InstalledRepository): FoundPullRequest {
  const basic = parsePullRequest(value, repository);
  const draft = (value as Record<string, unknown>).draft;
  return typeof draft === "boolean" ? { ...basic, isDraft: draft } : basic;
}

function parsePullRequestDetails(
  value: unknown,
  repository: InstalledRepository,
): GitHubPullRequestDetails {
  const basic = parsePullRequest(value, repository);
  const candidate = value as Record<string, unknown>;
  const head = candidate.head;
  const base = candidate.base;
  if (
    (candidate.state !== "open" && candidate.state !== "closed") ||
    typeof candidate.merged !== "boolean" ||
    !head || typeof head !== "object" || Array.isArray(head) ||
    !base || typeof base !== "object" || Array.isArray(base) ||
    typeof (head as Record<string, unknown>).ref !== "string" ||
    typeof (head as Record<string, unknown>).sha !== "string" ||
    !/^[a-f0-9]{40,64}$/u.test((head as Record<string, unknown>).sha as string) ||
    typeof (base as Record<string, unknown>).ref !== "string" ||
    typeof candidate.title !== "string" ||
    (candidate.body !== null && typeof candidate.body !== "string") ||
    (candidate.merge_commit_sha !== null && typeof candidate.merge_commit_sha !== "string")
  ) {
    throw agentXError("RUNTIME_UNAVAILABLE", "GitHub returned an invalid pull request response");
  }
  // AgentX opens its pull requests from a branch of the base repository: a head in another repository (a fork, or a
  // deleted fork, which leaves no head repository) is never one of them.
  const headRepository = (head as Record<string, unknown>).repo;
  const headFullName = headRepository && typeof headRepository === "object" ? (headRepository as Record<string, unknown>).full_name : undefined;
  if (typeof headFullName !== "string" || headFullName.toLowerCase() !== `${repository.owner}/${repository.name}`.toLowerCase()) {
    throw agentXError("RUNTIME_UNAVAILABLE", "GitHub returned a pull request from another repository");
  }
  return {
    ...basic,
    state: candidate.merged ? "merged" : candidate.state,
    headBranch: (head as Record<string, unknown>).ref as string,
    baseBranch: (base as Record<string, unknown>).ref as string,
    headCommit: (head as Record<string, unknown>).sha as string,
    ...(typeof candidate.merge_commit_sha === "string" ? { mergeCommit: candidate.merge_commit_sha } : {}),
    title: candidate.title,
    body: candidate.body ?? "",
  };
}

export function createGitHubAppJwt(appId: string, privateKey: string, nowMilliseconds: number): string {
  const issuedAt = Math.floor(nowMilliseconds / 1_000) - 60;
  const header = base64urlJson({ alg: "RS256", typ: "JWT" });
  const payload = base64urlJson({ iat: issuedAt, exp: issuedAt + 600, iss: appId });
  const signingInput = `${header}.${payload}`;
  try {
    const signer = createSign("RSA-SHA256");
    signer.update(signingInput);
    signer.end();
    return `${signingInput}.${signer.sign(privateKey).toString("base64url")}`;
  } catch (error) {
    if (isAgentXError(error)) throw error;
    throw agentXError("RUNTIME_UNAVAILABLE", "GitHub App private key could not sign a token");
  }
}

export function privateKeyFromSecret(secret: string): string {
  const trimmed = secret.trim();
  if (trimmed.startsWith("-----BEGIN")) return trimmed;
  try {
    const value = JSON.parse(trimmed) as unknown;
    if (
      value &&
      typeof value === "object" &&
      "privateKey" in value &&
      typeof value.privateKey === "string" &&
      value.privateKey.trim().startsWith("-----BEGIN")
    ) {
      return value.privateKey.trim();
    }
  } catch {
    // Report one stable error below without reflecting secret contents.
  }
  throw agentXError("RUNTIME_UNAVAILABLE", "GitHub App private-key secret is not a PEM key");
}

/** The App's id from the secret `agentx init` stores (`{"appId", "privateKey", ...}`). A secret
 * holding only a PEM key has none: its control plane passes GITHUB_APP_ID instead. */
export function appIdFromSecret(secret: string): string {
  try {
    const value = JSON.parse(secret.trim()) as unknown;
    if (value && typeof value === "object" && "appId" in value && typeof value.appId === "string" && GITHUB_APP_ID.test(value.appId)) {
      return value.appId;
    }
  } catch {
    // Report one stable error below without reflecting secret contents.
  }
  throw agentXError("RUNTIME_UNAVAILABLE", "GitHub App secret holds no appId; set the control plane's GitHubAppId parameter");
}

const GITHUB_WEBHOOK_SECRET_MISSING = "GitHub App secret does not contain a valid webhook secret";

/** True for the refusal webhookSecretFromSecret raises when the App secret has no usable webhook secret. */
export function isWebhookSecretMissing(error: unknown): boolean {
  return isAgentXError(error) && error.code === "RUNTIME_UNAVAILABLE" && error.message.endsWith(GITHUB_WEBHOOK_SECRET_MISSING);
}

/** Reads the optional webhook HMAC secret from the same protected App secret JSON object. */
export function webhookSecretFromSecret(secret: string): string {
  try {
    const value = JSON.parse(secret.trim()) as unknown;
    if (value && typeof value === "object" && "webhookSecret" in value && typeof value.webhookSecret === "string") {
      const webhookSecret = value.webhookSecret.trim();
      if (webhookSecret.length >= 32 && Buffer.byteLength(webhookSecret, "utf8") <= 4_096) return webhookSecret;
    }
  } catch {
    // Do not include secret material in errors.
  }
  throw agentXError("RUNTIME_UNAVAILABLE", GITHUB_WEBHOOK_SECRET_MISSING);
}

export function parseGitHubRepository(repositoryUrl: string): { owner: string; name: string } {
  let url: URL;
  try {
    url = new URL(repositoryUrl);
  } catch {
    // An address that is not a URL at all (for example `git@gitlab.com:org/repo`): say "github.com only" when it names another host.
    const named = /^(?:[a-z][a-z0-9+.-]*:\/\/)?(?:[^@\s/]+@)?([A-Za-z0-9-]+(?:\.[A-Za-z0-9-]+)+)[:/]/.exec(repositoryUrl.trim())?.[1];
    throw agentXError("CONFIG_INVALID", named !== undefined && named.toLowerCase() !== "github.com"
      ? "GitHub repository URL is invalid: only github.com repositories are supported"
      : "GitHub repository URL is invalid");
  }
  const segments = url.pathname.split("/").filter(Boolean);
  if (
    url.protocol !== "https:" ||
    url.hostname.toLowerCase() !== "github.com" ||
    url.port !== "" ||
    url.username !== "" ||
    url.password !== "" ||
    url.search !== "" ||
    url.hash !== "" ||
    segments.length !== 2 ||
    segments.some((segment) => segment.includes("%"))
  ) {
    // An empty host (`github.com:org/repo` parses as a scheme) is not another host: no blame.
    throw agentXError("CONFIG_INVALID", url.hostname === "" || url.hostname.toLowerCase() === "github.com"
      ? "credentialed repository must be a canonical GitHub HTTPS URL"
      : "credentialed repository must be a canonical GitHub HTTPS URL: only github.com repositories are supported");
  }
  const [owner, rawName] = segments;
  const name = rawName?.endsWith(".git") ? rawName.slice(0, -4) : rawName;
  if (
    !owner ||
    !/^[A-Za-z0-9](?:[A-Za-z0-9-]{0,38})$/.test(owner) ||
    !name ||
    !/^[A-Za-z0-9_.-]{1,100}$/.test(name)
  ) {
    throw agentXError("CONFIG_INVALID", "credentialed repository must be a canonical GitHub HTTPS URL");
  }
  return { owner, name };
}

function base64urlJson(value: unknown): string {
  return Buffer.from(JSON.stringify(value)).toString("base64url");
}

function isAgentXError(error: unknown): error is AgentXError {
  return error instanceof Error && error.name === "AgentXError";
}
