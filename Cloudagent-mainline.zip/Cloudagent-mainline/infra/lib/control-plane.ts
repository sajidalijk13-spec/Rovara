import { grantProviderKeySecrets } from "./model-keys.js";
import { resolve } from "node:path";
import {
  ArnFormat,
  Aws,
  CfnCondition,
  CfnOutput,
  CfnParameter,
  Duration,
  Fn,
  RemovalPolicy,
  Stack,
  type StackProps,
  Token,
  aws_apigatewayv2 as apigwv2,
  aws_budgets as budgets,
  aws_cloudwatch as cloudwatch,
  aws_cloudwatch_actions as cloudwatchActions,
  aws_dynamodb as dynamodb,
  aws_iam as iam,
  aws_kms as kms,
  aws_lambda as lambda,
  aws_lambda_destinations as lambdaDestinations,
  aws_lambda_nodejs as lambdaNodejs,
  aws_logs as logs,
  aws_s3 as s3,
  aws_scheduler as scheduler,
  aws_scheduler_targets as schedulerTargets,
  aws_secretsmanager as secretsmanager,
  aws_sns as sns,
  aws_sqs as sqs,
} from "aws-cdk-lib";
import type { Construct } from "constructs";
import { E2E_ARTIFACT_RETENTION_DAYS, E2E_ARTIFACT_RETENTION_TAG_KEY, E2E_ARTIFACT_RETENTION_TAG_VALUE, HEALTH_ALARM_SUFFIXES, INDEX_EXPIRY_ATTRIBUTE, WORKER_SETTING_PARAMETERS, WORKFLOW_DISPATCH_DUE_INDEX, WORKSPACE_PROJECT_INDEX, WORKSPACE_SESSION_STATE_INDEX } from "@agentx/contracts";
import { type AgentXNaming, legacyNaming } from "./naming.js";
import { ChannelAdapters } from "./channel-adapters.js";
import { DeveloperSignIn, developerSignInParameters } from "./developer-signin.js";
import { TaskPersonProof } from "./task-person-proof.js";
import { DeveloperTaskNotifier } from "./developer-task-notifier.js";
import { SessionLifecycle } from "./session-lifecycle.js";
import { REQUALIFY_CONTEXT_KEY, REQUALIFY_DEFAULT_HOUR_UTC, RuntimeRequalify } from "./runtime-requalify.js";
import { swebenchNames } from "./swebench-eval.js";
import { SWEBENCH_DEPLOYMENT_MODE } from "./swebench-eval-definition.js";

const MAX_DISPATCH_ATTEMPTS = 5;
// Matches MAX_RECEIVE_COUNT in packages/slack-service, which reports the final attempt in the thread.
export const SLACK_MAX_RECEIVE_COUNT = 5;
// What the ingress Lambda may read of a turn record for the Details view (spec 014 FR-024):
// TURN_DETAILS_ATTRIBUTES in packages/contracts/src/slack-details.ts plus the table keys pk and sk
// (required). The byTime index keys exportPk and exportSk are not needed by this policy and carry no
// new data; they stay listed so a later projection that names them is not refused.
// A contract test keeps the two lists equal.
export const TURN_DETAILS_READ_ATTRIBUTES = [
  "pk", "sk", "exportPk", "exportSk",
  "eventId", "subject", "receivedAt", "requestedBy", "disposition", "durationMs", "model", "offeredTools", "calls",
  "callsTruncated", "emptyResponse", "usage", "usageError", "recordingErrors", "argumentsOmitted", "error", "expiresAt",
];

export interface ControlPlaneStackProps extends StackProps {
  naming?: AgentXNaming;
}

/**
 * Issue 206: the alarms in this app the health probe would not read: each must be named
 * `<prefix><suffix>` with a suffix from HEALTH_ALARM_SUFFIXES. Every stack of a named app is the
 * same environment, and alarm names are plain strings (naming.alarmName).
 */
function unlistedAlarms(scope: Construct, prefix: string): string[] {
  const listed = new Set<string>(HEALTH_ALARM_SUFFIXES.map((suffix) => `${prefix}${suffix}`));
  return scope.node.root.node.findAll().flatMap((construct) => {
    // CloudWatch returns a composite alarm only to a DescribeAlarms grant on *, which the broker has not.
    if (construct instanceof cloudwatch.CfnCompositeAlarm) return [`the health probe cannot read composite alarm ${construct.node.path}`];
    if (!(construct instanceof cloudwatch.CfnAlarm)) return [];
    const name = construct.alarmName;
    if (name !== undefined && !Token.isUnresolved(name) && listed.has(name)) return [];
    return [`the health probe does not read alarm ${construct.node.path} (${String(name)}): name it ${prefix}<suffix> and add the suffix to HEALTH_ALARM_SUFFIXES`];
  });
}

export class ControlPlaneStack extends Stack {
  constructor(scope: Construct, id: string, props?: ControlPlaneStackProps) {
    super(scope, id, props);
    const naming = props?.naming ?? legacyNaming();
    const projectSetupRuntimeCatalogId = `${naming.resourcePrefix}-project-setup-runtime-v1`;
    const e2eFeatureRuntimeCatalogId = `${naming.resourcePrefix}-e2e-mock-runtime-v1`;

    const oidcIssuer = new CfnParameter(this, "OidcIssuer", { type: "String" });
    const oidcAudience = new CfnParameter(this, "OidcAudience", { type: "String" });
    const callbackSigningKey = new CfnParameter(this, "CallbackSigningKey", {
      type: "String",
      noEcho: true,
      minLength: 32,
      description: "Random secret used to scope and authenticate worker callbacks",
    });
    const adminClaim = new CfnParameter(this, "AdminClaim", {
      type: "String",
      default: "cognito:groups",
    });
    const adminValues = new CfnParameter(this, "AdminValues", {
      type: "String",
      default: '["agentx-admin"]',
      description: "JSON string array of claim values that grant AgentX administrator access",
    });
    const githubAppCredentialRef = new CfnParameter(this, "GitHubAppCredentialRef", {
      type: "String",
      default: "github-agentx-sdlc",
    });
    // No account or installation: the broker looks up the App's installation per repository owner (#123).
    // Empty: the broker reads the id from the private-key secret's appId. agentx init deploys the
    // control plane before it creates the GitHub App, so it has no id to pass yet.
    const githubAppId = new CfnParameter(this, "GitHubAppId", {
      type: "String",
      default: "",
      description: "GitHub App id; empty reads it from the private-key secret's appId",
    });
    const githubAppPrivateKeySecretArn = new CfnParameter(this, "GitHubAppPrivateKeySecretArn", {
      type: "String",
      description: "Complete Secrets Manager ARN containing the GitHub App private key PEM",
    });
    // Spec 025 phase 25a: declared on the stack itself so the names are exact. The legacy deployment (production) has
    // the developer task settings too, so it runs tasks as named environments do.
    const signInParameters = developerSignInParameters(this, { tasks: true });
    const taskPersonProofEnabled = naming.env === "agentxlivetest123" ? new CfnParameter(this, "TaskPersonProofEnabled", {
      type: "String",
      default: "false",
      allowedValues: ["true", "false"],
      description: "Install the dedicated task person proof workload in the approved named TEST environment",
    }) : undefined;

    const state = new dynamodb.Table(this, "State", {
      partitionKey: { name: "pk", type: dynamodb.AttributeType.STRING },
      sortKey: { name: "sk", type: dynamodb.AttributeType.STRING },
      billingMode: dynamodb.BillingMode.PAY_PER_REQUEST,
      encryption: dynamodb.TableEncryption.AWS_MANAGED,
      stream: dynamodb.StreamViewType.NEW_AND_OLD_IMAGES,
      pointInTimeRecoverySpecification: { pointInTimeRecoveryEnabled: true },
      // Retained: workspace and operation records must outlive a stack deletion.
      removalPolicy: RemovalPolicy.RETAIN,
      // Spec 025 A6 (Q5, owner answer 2026-09-30): failure and usage index items expire by TTL in
      // named environments. Adding a TTL to an existing table is an in-place update. 25c note 2: the
      // sharing items, NOTICE and CHANNEL_OPERATION, expire on it too; they exist only in named
      // environments (D14). No other State item carries indexExpiresAt (a test pins the files that
      // name it). The legacy table stays as it is.
      ...(naming.env === undefined ? {} : { timeToLiveAttribute: INDEX_EXPIRY_ATTRIBUTE }),
    });

    const artifacts = new s3.Bucket(this, "Artifacts", {
      blockPublicAccess: s3.BlockPublicAccess.BLOCK_ALL,
      encryption: s3.BucketEncryption.S3_MANAGED,
      enforceSSL: true,
      // M1.3 Task 3.7b, owner decision D4: a browser or API round's screenshots expire 30 days after they are written. A lifecycle filter matches the start of a key, and a screenshot's
      // key starts like every other private object's, so the rule matches the tag the broker puts on a screenshot and on nothing else. The bucket is not versioned: expiry deletes.
      // Named environments only: the legacy production template stays as it is.
      ...(naming.env === undefined ? {} : { lifecycleRules: [{ id: "ExpireE2EScreenshots", expiration: Duration.days(E2E_ARTIFACT_RETENTION_DAYS), tagFilters: { [E2E_ARTIFACT_RETENTION_TAG_KEY]: E2E_ARTIFACT_RETENTION_TAG_VALUE } }] }),
      // Retained: the broker's operation artifacts must outlive a stack deletion.
      removalPolicy: RemovalPolicy.RETAIN,
    });

    const deadLetterQueue = new sqs.Queue(this, "DispatchDeadLetterQueue", {
      encryption: sqs.QueueEncryption.SQS_MANAGED,
      retentionPeriod: Duration.days(14),
    });
    const dispatchQueue = new sqs.Queue(this, "DispatchQueue", {
      deadLetterQueue: { queue: deadLetterQueue, maxReceiveCount: MAX_DISPATCH_ATTEMPTS },
      encryption: sqs.QueueEncryption.SQS_MANAGED,
      visibilityTimeout: Duration.minutes(2),
    });

    const broker = packagedFunction(this, "Broker", "packages/broker/src/aws/broker.ts", {
      STATE_TABLE_NAME: state.tableName,
      AGENTX_PROJECT_SETUP_RUNTIME_CATALOG_ID: projectSetupRuntimeCatalogId,
      AGENTX_E2E_FEATURE_RUNTIME_CATALOG_ID: e2eFeatureRuntimeCatalogId,
      ARTIFACT_BUCKET_NAME: artifacts.bucketName,
      OIDC_ISSUER: oidcIssuer.valueAsString,
      ADMIN_CLAIM: adminClaim.valueAsString,
      ADMIN_VALUES: adminValues.valueAsString,
      CALLBACK_SIGNING_KEY: callbackSigningKey.valueAsString,
      GITHUB_APP_CREDENTIAL_REF: githubAppCredentialRef.valueAsString,
      GITHUB_APP_ID: githubAppId.valueAsString,
      GITHUB_APP_PRIVATE_KEY_SECRET_ARN: githubAppPrivateKeySecretArn.valueAsString,
    });
    state.grantReadWriteData(broker);
    artifacts.grantReadWrite(broker);
    broker.addToRolePolicy(new iam.PolicyStatement({
      actions: ["secretsmanager:GetSecretValue"],
      resources: [githubAppPrivateKeySecretArn.valueAsString],
    }));
    broker.addToRolePolicy(new iam.PolicyStatement({
      actions: ["secretsmanager:GetSecretValue"],
      resources: [this.formatArn({ service: "secretsmanager", resource: "secret", resourceName: `${naming.connectorSecretPrefix}*`, arnFormat: ArnFormat.COLON_RESOURCE_NAME })],
    }));
    // A rotated OAuth refresh token is written back to its own secret. Only secrets that
    // `agentx admin credential authorize` tagged for it are writable, never other connector secrets.
    broker.addToRolePolicy(new iam.PolicyStatement({
      actions: ["secretsmanager:PutSecretValue"],
      resources: [this.formatArn({ service: "secretsmanager", resource: "secret", resourceName: `${naming.connectorSecretPrefix}*`, arnFormat: ArnFormat.COLON_RESOURCE_NAME })],
      conditions: { StringEquals: { "secretsmanager:ResourceTag/agentx-writable": "refresh-token" } },
    }));
    broker.addToRolePolicy(new iam.PolicyStatement({
      actions: ["codebuild:StartBuild", "codebuild:BatchGetBuilds"],
      resources: [this.formatArn({ service: "codebuild", resource: "project", resourceName: "agentx-*" })],
    }));
    if (naming.env !== undefined) broker.addEnvironment("CONNECTOR_SECRET_PREFIX", naming.connectorSecretPrefix);
    // Spec 043: SWE-bench runs. The broker reads the optional eval stack's settings, the runner image
    // and the worker model per request, and starts the eval state machine by its fixed name; both
    // exist only once the eval stack is deployed, and until then a run is refused as not installed.
    broker.addEnvironment("SWEBENCH_SETTINGS_PREFIX", naming.ec2.workerSettingsPrefix);
    // M1.4 Task 4.10 (PREFIXGAP): the broker derives the AI navigation route from the installation's worker settings only when it knows where they are. Nothing ever set this, so setup
    // approval said "AI navigation steps will not run" and dispatch offered none. Named environments only: the legacy production template stays as it is. The read grant below covers it.
    if (naming.env !== undefined) broker.addEnvironment("AGENTX_E2E_AGENT_SETTINGS_PREFIX", naming.ec2.workerSettingsPrefix);
    const swebenchParameterArns = [
      swebenchNames(naming).settingsParameterName,
      swebenchNames(naming).runnerImageParameterName,
      swebenchNames(naming).runnerFeaturesParameterName,
      ...Object.values(WORKER_SETTING_PARAMETERS).map((name) => `${naming.ec2.workerSettingsPrefix}${name}`),
    ].map((name) => `arn:${Aws.PARTITION}:ssm:${Aws.REGION}:${Aws.ACCOUNT_ID}:parameter${name}`);
    // The eval batch tick reads the SWE-bench settings and the worker settings the deployment reads for an eval run, but never the AI navigation model setting (Task 4.10A review M-2) or the missing-key fallback model (Task 4.10D): it boots no worker and runs no model of its own.
    const evalSettingArns = [
      swebenchNames(naming).settingsParameterName,
      swebenchNames(naming).runnerImageParameterName,
      swebenchNames(naming).runnerFeaturesParameterName,
      ...Object.entries(WORKER_SETTING_PARAMETERS).filter(([key]) => key !== "e2eAgentModel" && key !== "modelFallback").map(([, name]) => `${naming.ec2.workerSettingsPrefix}${name}`),
    ].map((name) => `arn:${Aws.PARTITION}:ssm:${Aws.REGION}:${Aws.ACCOUNT_ID}:parameter${name}`);
    const swebenchStateMachineArn = this.formatArn({ service: "states", resource: "stateMachine", resourceName: swebenchNames(naming).stateMachineName, arnFormat: ArnFormat.COLON_RESOURCE_NAME });
    broker.addToRolePolicy(new iam.PolicyStatement({ actions: ["ssm:GetParameters"], resources: swebenchParameterArns }));
    broker.addToRolePolicy(new iam.PolicyStatement({ actions: ["states:StartExecution"], resources: [swebenchStateMachineArn] }));

    // Spec 061: a stored plan's cited code is read from GitHub in the background, with retries, so a slow or failing
    // GitHub never holds up the plan. The broker starts the job right after the plan commits (an async invoke), and
    // its recovery sweep starts any row that is due; the job needs nothing from the broker. 150 seconds: the code is
    // read inside 120, and the rest is for attaching the bundle and cleaning up. 1,024 MB: files are read in memory.
    // Developer tasks, and so their plans, exist only in named environments; the legacy templates gain nothing.
    if (naming.env !== undefined) {
      const planEvidence = packagedFunction(this, "PlanEvidence", "packages/broker/src/aws/plan-evidence-handler.ts", {
        STATE_TABLE_NAME: state.tableName,
        ARTIFACT_BUCKET_NAME: artifacts.bucketName,
        GITHUB_APP_CREDENTIAL_REF: githubAppCredentialRef.valueAsString,
        GITHUB_APP_ID: githubAppId.valueAsString,
        GITHUB_APP_PRIVATE_KEY_SECRET_ARN: githubAppPrivateKeySecretArn.valueAsString,
      }, Duration.seconds(150), [], 1024);
      // The State table, one action at a time, each on the partitions it needs (the sort key cannot be narrowed here):
      // reads of the task record, its evidence pointer, the job rows and the project revision the task started from; the
      // pointer is written with PutItem (DEVTASK#, put once, never the task record's workflow); the job row is claimed and
      // rescheduled with UpdateItem and removed with DeleteItem. No Query: the sweep runs in the broker.
      planEvidence.addToRolePolicy(new iam.PolicyStatement({
        sid: "ReadTaskJobAndProject",
        actions: ["dynamodb:GetItem"],
        resources: [state.tableArn],
        conditions: { "ForAllValues:StringLike": { "dynamodb:LeadingKeys": ["DEVTASK#*", "PLAN_EVIDENCE", "PROJECT#*"] } },
      }));
      planEvidence.addToRolePolicy(new iam.PolicyStatement({
        sid: "PutEvidencePointer",
        actions: ["dynamodb:PutItem"],
        resources: [state.tableArn],
        conditions: { "ForAllValues:StringLike": { "dynamodb:LeadingKeys": ["DEVTASK#*"] } },
      }));
      planEvidence.addToRolePolicy(new iam.PolicyStatement({
        sid: "ClaimAndCloseJobRow",
        actions: ["dynamodb:UpdateItem", "dynamodb:DeleteItem"],
        resources: [state.tableArn],
        conditions: { "ForAllValues:StringLike": { "dynamodb:LeadingKeys": ["PLAN_EVIDENCE"] } },
      }));
      // The plan is read back from its own folder, and the bundle is written only beside it.
      planEvidence.addToRolePolicy(new iam.PolicyStatement({ sid: "ReadPlanDocuments", actions: ["s3:GetObject"], resources: [artifacts.arnForObjects("private/*")] }));
      planEvidence.addToRolePolicy(new iam.PolicyStatement({ sid: "WriteEvidenceBundles", actions: ["s3:PutObject"], resources: [artifacts.arnForObjects("private/*/plan-documents/*.evidence.*.json")] }));
      // The GitHub App's key, to read files as the broker does.
      planEvidence.addToRolePolicy(new iam.PolicyStatement({ sid: "GitHubAppKey", actions: ["secretsmanager:GetSecretValue"], resources: [githubAppPrivateKeySecretArn.valueAsString] }));
      planEvidence.grantInvoke(broker);
      broker.addEnvironment("PLAN_EVIDENCE_FUNCTION_NAME", planEvidence.functionName);
    }

    const outboxPublisher = packagedFunction(
      this,
      "OutboxPublisher",
      "packages/broker/src/aws/outbox-publisher.ts",
      {
        STATE_TABLE_NAME: state.tableName,
        DISPATCH_QUEUE_URL: dispatchQueue.queueUrl,
      },
    );
    state.grantStreamRead(outboxPublisher);
    state.grantReadWriteData(outboxPublisher);
    dispatchQueue.grantSendMessages(outboxPublisher);
    // The State table's stream has two readers: this outbox publisher and, in named environments,
    // the DeveloperTaskNotifier (developer-task-notifier.ts). That is the per-shard maximum AWS
    // recommends: later phases (such as 25e's Slack Confirm DMs) add filters to an existing
    // trigger, never a third reader.
    new lambda.EventSourceMapping(this, "OutboxStreamMapping", {
      target: outboxPublisher,
      eventSourceArn: state.tableStreamArn!,
      startingPosition: lambda.StartingPosition.LATEST,
      batchSize: 100,
      retryAttempts: 3,
      bisectBatchOnError: true,
    });

    const dispatcher = packagedFunction(
      this,
      "Dispatcher",
      "packages/broker/src/aws/dispatcher.ts",
      {
        STATE_TABLE_NAME: state.tableName,
        AGENTX_PROJECT_SETUP_RUNTIME_CATALOG_ID: projectSetupRuntimeCatalogId,
        MAX_DISPATCH_ATTEMPTS: String(MAX_DISPATCH_ATTEMPTS),
        ARTIFACT_BUCKET_NAME: artifacts.bucketName,
      },
      Duration.seconds(60),
    );
    dispatchQueue.grantConsumeMessages(dispatcher);
    state.grantReadWriteData(dispatcher);
    // The dispatcher holds a CHECKS reference's kind to the admission it names; it reads only the immutable admission objects.
    dispatcher.addToRolePolicy(new iam.PolicyStatement({ actions: ["s3:GetObject"], resources: [artifacts.arnForObjects("workflow-e2e-admissions/*")] }));
    // EC2 workers (#76): the idle reaper and reconciler find sessions by state through this sparse index.
    state.addGlobalSecondaryIndex({
      indexName: WORKSPACE_SESSION_STATE_INDEX.name,
      partitionKey: { name: WORKSPACE_SESSION_STATE_INDEX.partitionKey, type: dynamodb.AttributeType.STRING },
      sortKey: { name: WORKSPACE_SESSION_STATE_INDEX.sortKey, type: dynamodb.AttributeType.STRING },
      projectionType: dynamodb.ProjectionType.ALL,
    });
    // Spec 041: GET /v1/dev/workspaces lists a project's workspaces through this sparse index.
    // Only workspace META items carry `workspaceProject`, so nothing else is indexed.
    state.addGlobalSecondaryIndex({
      indexName: WORKSPACE_PROJECT_INDEX.name,
      partitionKey: { name: WORKSPACE_PROJECT_INDEX.partitionKey, type: dynamodb.AttributeType.STRING },
      sortKey: { name: WORKSPACE_PROJECT_INDEX.sortKey, type: dynamodb.AttributeType.STRING },
      projectionType: dynamodb.ProjectionType.ALL,
    });
    // Sparse due-time index: only received, retryable, or leased GitHub deliveries carry these keys.
    state.addGlobalSecondaryIndex({
      indexName: "github-webhook-recovery",
      partitionKey: { name: "webhookRecoveryPk", type: dynamodb.AttributeType.STRING },
      sortKey: { name: "webhookRecoverySk", type: dynamodb.AttributeType.STRING },
      projectionType: dynamodb.ProjectionType.ALL,
    });
    // Gap 6: sparse due-time index over workflow dispatch rows, so the recovery sweep reads due rows first.
    state.addGlobalSecondaryIndex({
      indexName: WORKFLOW_DISPATCH_DUE_INDEX.name,
      partitionKey: { name: WORKFLOW_DISPATCH_DUE_INDEX.partitionKey, type: dynamodb.AttributeType.STRING },
      sortKey: { name: WORKFLOW_DISPATCH_DUE_INDEX.sortKey, type: dynamodb.AttributeType.STRING },
      projectionType: dynamodb.ProjectionType.ALL,
    });
    // The dispatcher signs each invocation to an EC2 worker; workers verify with the public key
    // alone (#80). Only the dispatcher may sign: the key policy denies kms:Sign to every other
    // principal, whatever its IAM policy grants.
    const invokeSigningKey = new kms.Key(this, "InvokeSigningKey", {
      alias: naming.ec2.invokeSigningKeyAlias,
      description: `Signs AgentX ${naming.environmentTagValue} invocations to EC2 workers`,
      keySpec: kms.KeySpec.ECC_NIST_P256,
      keyUsage: kms.KeyUsage.SIGN_VERIFY,
      pendingWindow: Duration.days(7),
      // Tokens live 60 seconds and workers get the public key at boot, so nothing outlives the key.
      removalPolicy: RemovalPolicy.DESTROY,
    });
    invokeSigningKey.grant(dispatcher, "kms:Sign");
    invokeSigningKey.addToResourcePolicy(new iam.PolicyStatement({
      sid: "SignOnlyAsDispatcher",
      effect: iam.Effect.DENY,
      principals: [new iam.AnyPrincipal()],
      actions: ["kms:Sign"],
      resources: ["*"],
      conditions: { ArnNotEquals: { "aws:PrincipalArn": dispatcher.role!.roleArn } },
    }));
    new CfnOutput(this, "InvokeSigningKeyArn", { value: invokeSigningKey.keyArn });

    new lambda.EventSourceMapping(this, "DispatchQueueMapping", {
      target: dispatcher,
      eventSourceArn: dispatchQueue.queueArn,
      batchSize: 1,
      reportBatchItemFailures: true,
    });

    const memberWorkspaceLimit = new CfnParameter(this, "SlackMemberWorkspaceLimit", {
      type: "Number",
      default: 3,
      minValue: 1,
      description: "Maximum Slack thread workspaces one channel member may start",
    });
    const organizationWorkspaceLimit = new CfnParameter(this, "SlackOrganizationWorkspaceLimit", {
      type: "Number",
      default: 20,
      minValue: 1,
      description: "Maximum Slack thread workspaces for the whole Slack organization",
    });
    // Operators store the real values with put-secret-value; the generated placeholder rejects every request until then.
    const slackSecret = new secretsmanager.Secret(this, "SlackSecret", {
      // Under environment naming, a fixed name under agentx/<env>/ so the operator role's secrets
      // scope covers it. The legacy deployment keeps its generated name.
      ...(naming.env === undefined ? {} : { secretName: `agentx/${naming.env}/slack` }),
      description: "AgentX Slack app credentials as JSON: {\"signingSecret\":\"...\",\"botToken\":\"xoxb-...\"}",
      generateSecretString: {
        secretStringTemplate: JSON.stringify({ botToken: "unset" }),
        generateStringKey: "signingSecret",
        excludePunctuation: true,
      },
      // Retained: the Slack app credentials must outlive a stack deletion.
      removalPolicy: RemovalPolicy.RETAIN,
    });
    const slackThreads = new dynamodb.Table(this, "SlackThreads", {
      partitionKey: { name: "pk", type: dynamodb.AttributeType.STRING },
      sortKey: { name: "sk", type: dynamodb.AttributeType.STRING },
      billingMode: dynamodb.BillingMode.PAY_PER_REQUEST,
      encryption: dynamodb.TableEncryption.AWS_MANAGED,
      timeToLiveAttribute: "expiresAt",
      // Retained: Slack thread state must outlive a stack deletion.
      removalPolicy: RemovalPolicy.RETAIN,
    });
    const slackDeadLetterQueue = new sqs.Queue(this, "SlackRequestDeadLetterQueue", {
      fifo: true,
      encryption: sqs.QueueEncryption.SQS_MANAGED,
      retentionPeriod: Duration.days(14),
    });
    const slackRequestQueue = new sqs.Queue(this, "SlackRequestQueue", {
      fifo: true,
      contentBasedDeduplication: false,
      deadLetterQueue: { queue: slackDeadLetterQueue, maxReceiveCount: SLACK_MAX_RECEIVE_COUNT },
      encryption: sqs.QueueEncryption.SQS_MANAGED,
      visibilityTimeout: Duration.minutes(15),
      retentionPeriod: Duration.days(4),
    });
    const threadSessions = new s3.Bucket(this, "SlackThreadSessions", {
      blockPublicAccess: s3.BlockPublicAccess.BLOCK_ALL,
      encryption: s3.BucketEncryption.S3_MANAGED,
      enforceSSL: true,
      versioned: true,
      lifecycleRules: [{ noncurrentVersionExpiration: Duration.days(30) }],
      // Retained: Pi thread sessions must outlive a stack deletion.
      removalPolicy: RemovalPolicy.RETAIN,
    });

    const slackOrchestratorRole = new iam.Role(this, "SlackOrchestratorTaskRole", {
      assumedBy: new iam.ServicePrincipal("ecs-tasks.amazonaws.com", {
        conditions: { StringEquals: { "aws:SourceAccount": this.account } },
      }),
      description: "Hosted AgentX Slack orchestrator; the only principal allowed on /v1/service routes",
    });
    slackRequestQueue.grantConsumeMessages(slackOrchestratorRole);
    // Spec 061 slice 2: "Ask AgentX to reply to this comment" on the task page queues the comment for the Slack service (send only).
    slackRequestQueue.grantSendMessages(broker);
    broker.addEnvironment("SLACK_REQUEST_QUEUE_URL", slackRequestQueue.queueUrl);
    slackThreads.grantReadWriteData(slackOrchestratorRole);
    threadSessions.grantReadWrite(slackOrchestratorRole);
    slackSecret.grantRead(slackOrchestratorRole);
    slackOrchestratorRole.addToPolicy(new iam.PolicyStatement({
      actions: ["bedrock:InvokeModel", "bedrock:InvokeModelWithResponseStream"],
      resources: [
        `arn:${this.partition}:bedrock:*::foundation-model/*`,
        `arn:${this.partition}:bedrock:${this.region}:${this.account}:inference-profile/*`,
      ],
    }));
    // One record per Slack event, kept 30 days for diagnosis and evaluation cases (feature 013 FR-025).
    // The broker reads it for the admin export. The ingress Lambda reads one record's non-text fields
    // for the Details view (spec 014), granted below. Nothing else can read it.
    const turnRecords = new dynamodb.Table(this, "TurnRecords", {
      partitionKey: { name: "pk", type: dynamodb.AttributeType.STRING },
      sortKey: { name: "sk", type: dynamodb.AttributeType.STRING },
      billingMode: dynamodb.BillingMode.PAY_PER_REQUEST,
      encryption: dynamodb.TableEncryption.AWS_MANAGED,
      timeToLiveAttribute: "expiresAt",
      // Retained: turn records are audit data that must outlive a stack deletion.
      removalPolicy: RemovalPolicy.RETAIN,
    });
    turnRecords.addGlobalSecondaryIndex({
      indexName: "byTime",
      partitionKey: { name: "exportPk", type: dynamodb.AttributeType.STRING },
      sortKey: { name: "exportSk", type: dynamodb.AttributeType.STRING },
      projectionType: dynamodb.ProjectionType.ALL,
    });
    // The service writes each record once with a condition and never reads the table back.
    slackOrchestratorRole.addToPolicy(new iam.PolicyStatement({
      actions: ["dynamodb:PutItem"],
      resources: [turnRecords.tableArn],
    }));
    // The admin export pages the time index newest first; the broker needs nothing else on this table.
    broker.addToRolePolicy(new iam.PolicyStatement({
      actions: ["dynamodb:Query"],
      resources: [turnRecords.tableArn, `${turnRecords.tableArn}/index/byTime`],
    }));
    broker.addEnvironment("TURN_RECORDS_TABLE_NAME", turnRecords.tableName);

    // No subscription by default: the deployer subscribes an email address or connects AWS Chatbot.
    const operatorAlerts = new sns.Topic(this, "OperatorAlerts", {
      topicName: naming.alertsTopicName,
      displayName: "AgentX operator alerts",
      enforceSSL: true,
    });
    // enforceSSL leaves only a Deny in the topic policy, which replaces SNS's default same-account
    // Allow, so the alarms need their own grant to publish.
    operatorAlerts.addToResourcePolicy(new iam.PolicyStatement({
      principals: [new iam.ServicePrincipal("cloudwatch.amazonaws.com")],
      actions: ["sns:Publish"],
      resources: [operatorAlerts.topicArn],
      conditions: {
        StringEquals: { "aws:SourceAccount": this.account },
        ArnLike: { "aws:SourceArn": `arn:${this.partition}:cloudwatch:${this.region}:${this.account}:alarm:*` },
      },
    }));
    // FR-047, environment naming only. AWS Budgets publishes the budget's notifications to the
    // same topic, so the topic policy must allow it (enforceSSL left only a Deny).
    if (naming.env !== undefined) {
      const budgetsTopicPublish = operatorAlerts.addToResourcePolicy(new iam.PolicyStatement({
        principals: [new iam.ServicePrincipal("budgets.amazonaws.com")],
        actions: ["sns:Publish"],
        resources: [operatorAlerts.topicArn],
        conditions: {
          StringEquals: { "aws:SourceAccount": this.account },
          ArnLike: { "aws:SourceArn": `arn:${this.partition}:budgets::${this.account}:*` },
        },
      }));
      const monthlyUsd = new CfnParameter(this, "BudgetMonthlyUsd", {
        type: "String", default: "0", allowedPattern: "^(0|[1-9][0-9]{0,6})$",
        description: "The environment's monthly AWS budget in US dollars; 0 means no budget",
      });
      const scope = new CfnParameter(this, "BudgetScope", {
        type: "String", default: "tag", allowedValues: ["tag", "account"],
        description: "tag: costs tagged agentx:env for this environment (the tag must be activated in Billing); account: the whole account",
      });
      const hasBudget = new CfnCondition(this, "HasBudget", { expression: Fn.conditionNot(Fn.conditionEquals(monthlyUsd.valueAsString, "0")) });
      const byTag = new CfnCondition(this, "BudgetByTag", { expression: Fn.conditionEquals(scope.valueAsString, "tag") });
      const notify = (type: "ACTUAL" | "FORECASTED", threshold: number) => ({
        notification: { notificationType: type, comparisonOperator: "GREATER_THAN", threshold, thresholdType: "PERCENTAGE" },
        subscribers: [{ subscriptionType: "SNS", address: operatorAlerts.topicArn }],
      });
      const budget = new budgets.CfnBudget(this, "MonthlyBudget", {
        budget: {
          budgetName: naming.alarmName("monthly"),
          budgetType: "COST",
          timeUnit: "MONTHLY",
          // CloudFormation passes the parameter's string; the Budgets resource accepts it as its number.
          budgetLimit: { amount: Token.asNumber(monthlyUsd.valueAsString), unit: "USD" },
          costFilters: Fn.conditionIf(byTag.logicalId, { TagKeyValue: [`user:agentx:env$${naming.env}`] }, Aws.NO_VALUE),
        },
        notificationsWithSubscribers: [notify("ACTUAL", 80), notify("FORECASTED", 100)],
        // C5 / FR-047: every resource the installer creates carries agentx:env. AWS::Budgets::Budget
        // takes tags through ResourceTags rather than the stack's Tags.of(app), so it is set here
        // explicitly; Tags.of(app) does not reach this resource.
        resourceTags: [{ key: "agentx:env", value: naming.env }],
      });
      budget.cfnOptions.condition = hasBudget;
      // AWS Budgets creates the notification's SNS subscriber as part of creating the budget, so the
      // topic policy above must already allow budgets.amazonaws.com to publish before that happens;
      // otherwise the subscription confirmation publish could race ahead of the policy statement.
      if (budgetsTopicPublish.policyDependable !== undefined) budget.node.addDependency(budgetsTopicPublish.policyDependable);
    }
    const notifyOperator = new cloudwatchActions.SnsAction(operatorAlerts);
    // The broker publishes these in embedded metric format with a dimensionless series as well as a
    // per-connector one; the alarms read the dimensionless series, so they cover every connector.
    const agentxSum = (metricName: string, period: Duration) =>
      new cloudwatch.Metric({ namespace: naming.metricsNamespace, metricName, statistic: "Sum", period });
    if (naming.env !== undefined) broker.addEnvironment("AGENTX_METRICS_NAMESPACE", naming.metricsNamespace);
    new cloudwatch.Alarm(this, "ConnectorBrokenAlarm", {
      alarmName: naming.alarmName("ConnectorBroken"),
      alarmDescription: "A connector's discovery failed or a vendor changed an approved tool's schema. Check the broker logs for connector metrics and connector.* events.",
      metric: new cloudwatch.MathExpression({
        expression: "FILL(discovery, 0) + FILL(drift, 0)",
        usingMetrics: {
          discovery: agentxSum("ConnectorDiscoveryFailed", Duration.minutes(5)),
          drift: agentxSum("ConnectorSchemaDrift", Duration.minutes(5)),
        },
        period: Duration.minutes(5),
        label: "Connector discovery failures and schema drift",
      }),
      threshold: 1,
      evaluationPeriods: 1,
      comparisonOperator: cloudwatch.ComparisonOperator.GREATER_THAN_OR_EQUAL_TO_THRESHOLD,
      treatMissingData: cloudwatch.TreatMissingData.NOT_BREACHING,
    }).addAlarmAction(notifyOperator);
    new cloudwatch.Alarm(this, "ConnectorNotConnectedAlarm", {
      alarmName: naming.alarmName("ConnectorNotConnected"),
      alarmDescription: "A connector's vendor credential is missing, revoked or rejected. Check the broker logs for the connector, then reconnect it with agentx connectors.",
      metric: agentxSum("ConnectorNotConnected", Duration.minutes(5)),
      threshold: 1,
      evaluationPeriods: 1,
      comparisonOperator: cloudwatch.ComparisonOperator.GREATER_THAN_OR_EQUAL_TO_THRESHOLD,
      treatMissingData: cloudwatch.TreatMissingData.NOT_BREACHING,
    }).addAlarmAction(notifyOperator);
    new cloudwatch.Alarm(this, "EmptyResponsesAlarm", {
      alarmName: naming.alarmName("EmptyResponses"),
      alarmDescription: "More than three orchestrator turns in an hour ended without text. Export recent turns with agentx admin turns export.",
      metric: agentxSum("TurnEmptyResponse", Duration.hours(1)),
      threshold: 3,
      evaluationPeriods: 1,
      comparisonOperator: cloudwatch.ComparisonOperator.GREATER_THAN_THRESHOLD,
      treatMissingData: cloudwatch.TreatMissingData.NOT_BREACHING,
    }).addAlarmAction(notifyOperator);
    new cloudwatch.Alarm(this, "RecordingFailuresAlarm", {
      alarmName: naming.alarmName("RecordingFailures"),
      alarmDescription: "Turn records or turn metrics are being lost: a turn record write failed or the Slack service could not emit turn metrics. Check the Slack orchestrator logs for turn_record.write_failed and turn_metrics.emit_failed. A write that timed out may still have landed, so check the table before assuming the record is lost.",
      metric: new cloudwatch.MathExpression({
        expression: "FILL(write,0) + FILL(emit,0)",
        usingMetrics: {
          write: agentxSum("TurnRecordWriteFailed", Duration.minutes(5)),
          emit: agentxSum("TurnMetricsEmitFailed", Duration.minutes(5)),
        },
        period: Duration.minutes(5),
        label: "Turn record write and turn metric emit failures",
      }),
      threshold: 1,
      evaluationPeriods: 1,
      comparisonOperator: cloudwatch.ComparisonOperator.GREATER_THAN_OR_EQUAL_TO_THRESHOLD,
      treatMissingData: cloudwatch.TreatMissingData.NOT_BREACHING,
    }).addAlarmAction(notifyOperator);
    // A request that fails its final attempt without reaching the processor's own reporting lands here
    // with no turn record and no other signal.
    new cloudwatch.Alarm(this, "SlackDeadLettersAlarm", {
      alarmName: naming.alarmName("SlackDeadLetters"),
      alarmDescription: "A Slack request exhausted its receives and is in the Slack request dead-letter queue. Check the Slack orchestrator logs for its event ID.",
      metric: slackDeadLetterQueue.metricApproximateNumberOfMessagesVisible({
        statistic: "Maximum",
        period: Duration.minutes(5),
      }),
      threshold: 1,
      evaluationPeriods: 1,
      comparisonOperator: cloudwatch.ComparisonOperator.GREATER_THAN_OR_EQUAL_TO_THRESHOLD,
      treatMissingData: cloudwatch.TreatMissingData.NOT_BREACHING,
    }).addAlarmAction(notifyOperator);
    // Issue #46, named environments only: a dispatch job that exhausts its receives lands here and
    // nothing else reports it. The legacy AgentXControlPlane template stays as it is.
    if (naming.env !== undefined) {
      new cloudwatch.Alarm(this, "DispatchDeadLettersAlarm", {
        alarmName: naming.alarmName("DispatchDeadLetters"),
        alarmDescription: "A worker dispatch job exhausted its receives and is in the dispatch dead-letter queue. Check the dispatcher logs for its operation ID, then redrive or purge the queue.",
        metric: deadLetterQueue.metricApproximateNumberOfMessagesVisible({
          statistic: "Maximum",
          period: Duration.minutes(5),
        }),
        threshold: 1,
        evaluationPeriods: 1,
        comparisonOperator: cloudwatch.ComparisonOperator.GREATER_THAN_OR_EQUAL_TO_THRESHOLD,
        treatMissingData: cloudwatch.TreatMissingData.NOT_BREACHING,
      }).addAlarmAction(notifyOperator);
    }

    broker.addEnvironment("SLACK_ORCHESTRATOR_ROLE_ARN", slackOrchestratorRole.roleArn);
    broker.addEnvironment("SLACK_MEMBER_WORKSPACE_LIMIT", memberWorkspaceLimit.valueAsString);
    broker.addEnvironment("SLACK_ORGANIZATION_WORKSPACE_LIMIT", organizationWorkspaceLimit.valueAsString);

    const appPostedMessages = new CfnParameter(this, "SlackAppPostedMessages", {
      type: "String",
      default: "accept",
      allowedValues: ["accept", "ignore"],
      description: "accept: answer mentions a person posts through another app with their own Slack token; ignore: answer only typed mentions",
    });
    const threadTurnsPerMinute = new CfnParameter(this, "SlackThreadTurnsPerMinute", {
      // A CloudFormation Number parameter accepts decimals (e.g. "6.5") within its min/max, which the
      // Lambda's own whole-number check then refuses at cold start, taking all Slack ingress down
      // with no alarm. A String with this pattern refuses that value at deploy time instead.
      type: "String",
      default: "6",
      allowedPattern: "^([1-9]|[1-5][0-9]|60)$",
      constraintDescription: "must be a whole number from 1 to 60",
      description: "Most requests one Slack thread may start in a minute; further requests pause the thread with one notice",
    });
    const slackIngress = packagedFunction(
      this,
      "SlackIngress",
      "packages/broker/src/aws/slack-ingress.ts",
      {
        STATE_TABLE_NAME: state.tableName,
        SLACK_THREADS_TABLE_NAME: slackThreads.tableName,
        SLACK_REQUEST_QUEUE_URL: slackRequestQueue.queueUrl,
        SLACK_SECRET_ARN: slackSecret.secretArn,
        SLACK_APP_POSTED_MESSAGES: appPostedMessages.valueAsString,
        SLACK_THREAD_TURNS_PER_MINUTE: threadTurnsPerMinute.valueAsString,
      },
      Duration.seconds(10),
    );
    slackIngress.addToRolePolicy(new iam.PolicyStatement({
      actions: ["dynamodb:GetItem"],
      resources: [state.tableArn],
      conditions: { "ForAllValues:StringLike": { "dynamodb:LeadingKeys": ["SLACK_BINDING#*"] } },
    }));
    slackThreads.grantReadWriteData(slackIngress);
    slackRequestQueue.grantSendMessages(slackIngress);
    // The stop command (#126): the broker cancels the thread's running task for the ingress, which
    // itself gets no write access to the state table and no callback key.
    slackIngress.addEnvironment("BROKER_FUNCTION_NAME", broker.functionName);
    broker.grantInvoke(slackIngress);
    slackSecret.grantRead(slackIngress);
    // The Details view (spec 014 FR-024): Slack's interactivity request runs on this Lambda and must
    // open the modal within 3 seconds, so it reads the one turn record the clicked button names, by
    // key. It may read only the attributes the view shows: never the request or response text, the
    // workspace or the worker operations. No Query or Scan, and no index.
    slackIngress.addToRolePolicy(new iam.PolicyStatement({
      actions: ["dynamodb:GetItem"],
      resources: [turnRecords.tableArn],
      conditions: {
        "ForAllValues:StringLike": { "dynamodb:LeadingKeys": ["THREAD#*"] },
        "ForAllValues:StringEquals": { "dynamodb:Attributes": TURN_DETAILS_READ_ATTRIBUTES },
        StringEqualsIfExists: { "dynamodb:Select": "SPECIFIC_ATTRIBUTES" },
        // ForAllValues passes when dynamodb:Attributes is absent, and GetItem has no Select, so a read
        // without a ProjectionExpression (which returns every attribute) must be refused outright.
        Null: { "dynamodb:Attributes": "false" },
      },
    }));
    slackIngress.addEnvironment("TURN_RECORDS_TABLE_NAME", turnRecords.tableName);

    const api = new apigwv2.CfnApi(this, "HttpApi", {
      name: naming.apiName,
      protocolType: "HTTP",
    });
    const integration = new apigwv2.CfnIntegration(this, "BrokerIntegration", {
      apiId: api.ref,
      integrationType: "AWS_PROXY",
      integrationUri: broker.functionArn,
      payloadFormatVersion: "2.0",
    });
    const authorizer = new apigwv2.CfnAuthorizer(this, "JwtAuthorizer", {
      apiId: api.ref,
      authorizerType: "JWT",
      identitySource: ["$request.header.Authorization"],
      name: "agentx-jwt",
      jwtConfiguration: {
        audience: [oidcAudience.valueAsString],
        issuer: oidcIssuer.valueAsString,
      },
    });
    new apigwv2.CfnRoute(this, "ProxyRoute", {
      apiId: api.ref,
      routeKey: "ANY /{proxy+}",
      target: `integrations/${integration.ref}`,
      authorizationType: "JWT",
      authorizerId: authorizer.ref,
    });
    new apigwv2.CfnRoute(this, "WorkerCallbackRoute", {
      apiId: api.ref,
      routeKey: "POST /v1/internal/{proxy+}",
      target: `integrations/${integration.ref}`,
      authorizationType: "NONE",
    });
    // The setup worker authenticates this one source read with its short-lived project-setup
    // capability, which the broker verifies. Keep the API Gateway exception limited to this GET;
    // the generic internal callback route remains POST-only.
    new apigwv2.CfnRoute(this, "ProjectSetupExecutionReadRoute", {
      apiId: api.ref,
      routeKey: "GET /v1/internal/project-setups/{setupExecutionId}/execution",
      target: `integrations/${integration.ref}`,
      authorizationType: "NONE",
    });
    // GitHub signs webhook bodies itself; the broker verifies its HMAC and linked repository scope.
    new apigwv2.CfnRoute(this, "GithubWebhookRoute", {
      apiId: api.ref,
      routeKey: "POST /v1/github/webhooks",
      target: `integrations/${integration.ref}`,
      authorizationType: "NONE",
    });
    // Confused-deputy guard: only this account's own EventBridge schedules may assume the recovery roles.
    // Scheduler sets aws:SourceArn to the schedule group's ARN, not the schedule's; these schedules use the default group.
    const schedulerPrincipal = new iam.ServicePrincipal("scheduler.amazonaws.com", { conditions: {
      StringEquals: {
        "aws:SourceAccount": this.account,
        "aws:SourceArn": `arn:${this.partition}:scheduler:${this.region}:${this.account}:schedule-group/default`,
      },
    } });
    const githubRecoveryRole = new iam.Role(this, "GithubWebhookRecoveryRole", {
      assumedBy: schedulerPrincipal,
    });
    broker.grantInvoke(githubRecoveryRole);
    new scheduler.CfnSchedule(this, "GithubWebhookRecoverySchedule", {
      flexibleTimeWindow: { mode: "OFF" },
      scheduleExpression: "rate(1 minute)",
      state: "ENABLED",
      target: {
        arn: broker.functionArn,
        roleArn: githubRecoveryRole.roleArn,
        input: JSON.stringify({ source: "agentx.github-webhook-recovery" }),
        retryPolicy: { maximumRetryAttempts: 2, maximumEventAgeInSeconds: 300 },
      },
    });
    new scheduler.CfnSchedule(this, "WorkflowMergeRecoverySchedule", {
      flexibleTimeWindow: { mode: "OFF" },
      scheduleExpression: "rate(1 minute)",
      state: "ENABLED",
      target: {
        arn: broker.functionArn,
        roleArn: githubRecoveryRole.roleArn,
        input: JSON.stringify({ source: "agentx.workflow-merge-recovery" }),
        retryPolicy: { maximumRetryAttempts: 2, maximumEventAgeInSeconds: 300 },
      },
    });
    // Gap 6: re-run any workflow dispatch (an automatic review start) left behind after its result committed.
    const workflowDispatchRecoveryRole = new iam.Role(this, "WorkflowDispatchRecoveryRole", {
      assumedBy: schedulerPrincipal,
    });
    broker.grantInvoke(workflowDispatchRecoveryRole);
    new scheduler.CfnSchedule(this, "WorkflowDispatchRecoverySchedule", {
      flexibleTimeWindow: { mode: "OFF" },
      scheduleExpression: "rate(1 minute)",
      state: "ENABLED",
      target: {
        arn: broker.functionArn,
        roleArn: workflowDispatchRecoveryRole.roleArn,
        input: JSON.stringify({ source: "agentx.workflow-dispatch-recovery" }),
        retryPolicy: { maximumRetryAttempts: 2, maximumEventAgeInSeconds: 300 },
      },
    });
    const defaultStage = new apigwv2.CfnStage(this, "DefaultStage", {
      apiId: api.ref,
      stageName: "$default",
      autoDeploy: true,
    });
    broker.addPermission("ApiInvoke", {
      principal: new iam.ServicePrincipal("apigateway.amazonaws.com"),
      sourceArn: `arn:${this.partition}:execute-api:${this.region}:${this.account}:${api.ref}/*/*/*`,
    });

    const slackIntegration = new apigwv2.CfnIntegration(this, "SlackIngressIntegration", {
      apiId: api.ref,
      integrationType: "AWS_PROXY",
      integrationUri: slackIngress.functionArn,
      payloadFormatVersion: "2.0",
    });
    new apigwv2.CfnRoute(this, "SlackEventsRoute", {
      apiId: api.ref,
      routeKey: "POST /v1/slack/events",
      target: `integrations/${slackIntegration.ref}`,
      authorizationType: "NONE",
    });
    // Slack's interactivity request URL (spec 014): signed button presses, handled by the same Lambda.
    new apigwv2.CfnRoute(this, "SlackInteractivityRoute", {
      apiId: api.ref,
      routeKey: "POST /v1/slack/interactions",
      target: `integrations/${slackIntegration.ref}`,
      authorizationType: "NONE",
    });
    new apigwv2.CfnRoute(this, "SlackServiceRoute", {
      apiId: api.ref,
      routeKey: "ANY /v1/service/{proxy+}",
      target: `integrations/${integration.ref}`,
      authorizationType: "AWS_IAM",
    });
    slackIngress.addPermission("ApiInvoke", {
      principal: new iam.ServicePrincipal("apigateway.amazonaws.com"),
      sourceArn: `arn:${this.partition}:execute-api:${this.region}:${this.account}:${api.ref}/*/*/v1/slack/events`,
    });
    slackIngress.addPermission("InteractivityInvoke", {
      principal: new iam.ServicePrincipal("apigateway.amazonaws.com"),
      sourceArn: `arn:${this.partition}:execute-api:${this.region}:${this.account}:${api.ref}/*/*/v1/slack/interactions`,
    });
    slackOrchestratorRole.addToPolicy(new iam.PolicyStatement({
      actions: ["execute-api:Invoke"],
      resources: [`arn:${this.partition}:execute-api:${this.region}:${this.account}:${api.ref}/*/*/v1/service/*`],
    }));

    // Spec 062: the channel API. Every deployment has the built-in Slack adapter, off until SlackViaChannel is enabled
    // (Phase 7d); named environments may also register other adapters, off until ChannelAdapters is enabled.
    const channelAdapters = new ChannelAdapters(this, "ChannelApi", {
      naming, env: naming.env ?? "production", api, state, broker, orchestratorRole: slackOrchestratorRole, notifyOperator,
      slack: { ingress: slackIngress, integration: slackIntegration, threads: slackThreads, appPostedMessages: appPostedMessages.valueAsString, threadTurnsPerMinute: threadTurnsPerMinute.valueAsString },
      registry: true, sharedTasks: naming.env !== undefined,
      turnRecords: { table: turnRecords, detailsAttributes: TURN_DETAILS_READ_ATTRIBUTES },
    });
    new CfnOutput(this, "SlackAdapterCommandsUrl", { value: `${api.attrApiEndpoint}/v1/slack/channel-commands` });
    new CfnOutput(this, "SlackAdapterSecretName", { value: `agentx/${naming.env ?? "production"}/channel-adapter/slack` });
    new CfnOutput(this, "ChannelRequestQueueUrl", { value: channelAdapters.requests.queueUrl });
    new CfnOutput(this, "ChannelEventQueueUrl", { value: channelAdapters.events.queueUrl });
    // Spec 025 phase 25a: developer sign-in and tasks, in every deployment; the legacy one is named production.
    const taskParameters = signInParameters.tasks;
    if (taskParameters !== undefined) {
      const developerSignIn = new DeveloperSignIn(this, "DeveloperSignIn", {
        naming, env: naming.env ?? "production", api, stage: defaultStage, brokerIntegration: integration, broker, slackSecret, parameters: signInParameters, turnRecords,
      });
      // Spec 063 FR-005: the admin client's own rule for who is an administrator, read at company sign-in.
      developerSignIn.function.addEnvironment("ADMIN_OIDC_ISSUER", oidcIssuer.valueAsString);
      developerSignIn.function.addEnvironment("ADMIN_CLAIM", adminClaim.valueAsString);
      developerSignIn.function.addEnvironment("ADMIN_VALUES", adminValues.valueAsString);
      if (naming.env === "agentxlivetest123" && taskPersonProofEnabled !== undefined) {
        new TaskPersonProof(this, "TaskPersonProof", {
          naming,
          enabled: taskPersonProofEnabled,
          slackTeamId: signInParameters.slackTeamId,
          slackSecret,
          developerSignInTable: developerSignIn.table,
          dispatcher,
        });
      }
      broker.addEnvironment("AGENTX_TASK_PEOPLE_CHANGES_ENABLED", taskParameters.taskPeopleChangesEnabled.valueAsString);
      broker.addEnvironment("AGENTX_TASK_PEOPLE_PUBLIC_INVITATIONS_ENABLED", taskParameters.taskPeoplePublicInvitationsEnabled.valueAsString);
      broker.addEnvironment("AGENTX_TASK_PEOPLE_PRIVATE_INVITATIONS_ENABLED", taskParameters.taskPeoplePrivateInvitationsEnabled.valueAsString);
      broker.addEnvironment("AGENTX_WORKFLOW_DEPENDENCIES_ENABLED", taskParameters.workflowDependenciesEnabled.valueAsString);
      // Sign in with ChatGPT (#338): seals each developer's ChatGPT tokens in the State table. A
      // connection belongs to a signed-in developer, so it exists only where developer sign-in
      // does. Only the broker encrypts and decrypts with it, always under an encryption context
      // naming the developer and the field. Deleting it (with the stack) only leaves connections to redo.
      const chatGptConnectionKey = new kms.Key(this, "ChatGptConnectionKey", {
        description: "AgentX: seals developers' Sign in with ChatGPT tokens",
        enableKeyRotation: true,
        pendingWindow: Duration.days(7),
        removalPolicy: RemovalPolicy.DESTROY,
      });
      chatGptConnectionKey.grant(broker, "kms:Encrypt", "kms:Decrypt");
      broker.addEnvironment("CHATGPT_CONNECTION_KEY_ARN", chatGptConnectionKey.keyArn);
      // Spec 025 phase 25c: sharing, named environments only (D14).
      const notifier = new DeveloperTaskNotifier(this, "DeveloperTaskNotifier", { naming, controlPlaneUrl: api.attrApiEndpoint, state, artifactBucket: artifacts, slackSecret, taskPeopleChangesEnabled: taskParameters.taskPeopleChangesEnabled, notifyOperator });
      // Spec 025 A13: the admin health route reads the environment's alarms, by name, and
      // the depths of its dead-letter queues. Read-only, and on exactly these resources.
      const alarmPrefix = naming.alarmName("");
      broker.addEnvironment("AGENTX_ALARM_PREFIX", alarmPrefix);
      // Issue 206: the probe reads them by exact name (HEALTH_ALARM_SUFFIXES), since a prefix listing
      // is authorized against * while a call naming its alarms is authorized against each alarm's
      // ARN, which this grant covers. A CDK alarm missing from that list would go unreported, so the
      // app refuses to synthesize one. This holds when an environment's stacks deploy from one
      // revision, as a release does: a stack deployed alone from a newer revision could add an
      // alarm this broker does not list.
      this.node.addValidation({ validate: () => unlistedAlarms(this, alarmPrefix) });
      broker.addToRolePolicy(new iam.PolicyStatement({
        actions: ["cloudwatch:DescribeAlarms"],
        resources: [`arn:${this.partition}:cloudwatch:${this.region}:${this.account}:alarm:${alarmPrefix}*`],
      }));
      channelAdapters.connectSlackPoster(notifier.function, signInParameters.slackTeamId.valueAsString);
      // Phase 7c1b: sign-in's Slack directory reads (task access, channel names, the health check).
      channelAdapters.connectSlackPoster(developerSignIn.function, signInParameters.slackTeamId.valueAsString);
      // Phase 7c2: the channel API's Slack router posts through the adapter too.
      channelAdapters.connectSlackPoster(channelAdapters.ingress, signInParameters.slackTeamId.valueAsString, { readsAdapterSecrets: true });

      // The channel request dead-letter queue is reported by its alarm only: one more queue ARN here pushes the broker
      // role's policy past IAM's inline size limit.
      const deadLetterQueues = {
        dispatch: deadLetterQueue, "slack-requests": slackDeadLetterQueue, "developer-notices": notifier.deadLetters, "developer-notice-stream": notifier.streamFailures,
        "channel-events": channelAdapters.eventDeadLetters,
      };
      broker.addEnvironment("HEALTH_DEAD_LETTER_QUEUES", this.toJsonString(Object.fromEntries(Object.entries(deadLetterQueues).map(([name, queue]) => [name, queue.queueUrl]))));
      broker.addToRolePolicy(new iam.PolicyStatement({
        actions: ["sqs:GetQueueAttributes"],
        resources: Object.values(deadLetterQueues).map((queue) => queue.queueArn),
      }));
      // C10: the ingress reads shared thread records by key; its SLACK_BINDING# statement is unchanged.
      slackIngress.addEnvironment("SHARED_TASKS", "enabled");
      slackIngress.addToRolePolicy(new iam.PolicyStatement({
        actions: ["dynamodb:GetItem"],
        resources: [state.tableArn],
        conditions: { "ForAllValues:StringLike": { "dynamodb:LeadingKeys": ["SHARED_TASK#*"] } },
      }));
      // Slack plan buttons read only the task owner, share binding, and saved workflow policy by key. Spec 062 Phase
      // 7c3: so does the channel API, which runs those buttons for the built-in Slack adapter.
      const taskButtonRead = () => new iam.PolicyStatement({
        actions: ["dynamodb:GetItem"],
        resources: [state.tableArn],
        conditions: {
          "ForAllValues:StringLike": { "dynamodb:LeadingKeys": ["DEVTASK#*"] },
          "ForAllValues:StringEquals": { "dynamodb:Attributes": ["pk", "sk", "slackUserId", "share", "workflow"] },
          StringEqualsIfExists: { "dynamodb:Select": "SPECIFIC_ATTRIBUTES" },
          Null: { "dynamodb:Attributes": "false" },
        },
      });
      slackIngress.addToRolePolicy(taskButtonRead());
      channelAdapters.ingress.addToRolePolicy(taskButtonRead());
      // Task 19 (gap 10h): a Quick or Full button takes the choice while Slack waits, then starts the task in an
      // asynchronous invoke of this same Lambda. A policy of its own, so the function does not wait on it (no cycle).
      new iam.Policy(this, "SlackIngressSelfInvoke", {
        roles: [slackIngress.role!],
        statements: [new iam.PolicyStatement({ actions: ["lambda:InvokeFunction"], resources: [slackIngress.functionArn] })],
      });
      // Task 19: an asynchronous invoke Lambda could not run (throttled past its retries, too old, or a crash) lands here,
      // and the operator is told: a Slack press handed to the broker or this Lambda's own Quick or Full start, and also
      // any other asynchronous broker invoke (a scheduled retry sweep). The handlers answer every expected refusal
      // themselves, so anything here is a lost request.
      const handOffFailures = new sqs.Queue(this, "SlackHandOffFailureQueue", {
        encryption: sqs.QueueEncryption.SQS_MANAGED,
        retentionPeriod: Duration.days(14),
      });
      broker.configureAsyncInvoke({ onFailure: new lambdaDestinations.SqsDestination(handOffFailures) });
      slackIngress.configureAsyncInvoke({ onFailure: new lambdaDestinations.SqsDestination(handOffFailures) });
      new cloudwatch.Alarm(this, "SlackHandOffFailuresAlarm", {
        alarmName: naming.alarmName("SlackHandOffFailures"),
        alarmDescription: "An AgentX background request (a Slack button press or a scheduled retry) was lost: Lambda could not run it, and it is in the Slack hand-off failure queue. Check the queue, and the broker and Slack ingress logs for its task or request ID.",
        // Each lost request alarms on its own: the count sent in five minutes, not the queue's depth (which stays up until
        // the queue is purged and would hide a later loss).
        metric: handOffFailures.metricNumberOfMessagesSent({ statistic: "Sum", period: Duration.minutes(5) }),
        threshold: 1,
        evaluationPeriods: 1,
        comparisonOperator: cloudwatch.ComparisonOperator.GREATER_THAN_OR_EQUAL_TO_THRESHOLD,
        treatMissingData: cloudwatch.TreatMissingData.NOT_BREACHING,
      }).addAlarmAction(notifyOperator);
      // Spec 025 E14 (C14): the interactivity route hands Slack Confirm and Cancel presses to the broker.
      slackIngress.addEnvironment("ADMIN_CHANGES", "enabled");
      // Spec 062 Phase 7c3b: the channel API takes Slack's presses and forms for the built-in adapter: admin change
      // presses, the Details view (the same field-limited read of one turn record) and a ChatGPT connection finished in
      // an asynchronous invoke of itself (a policy of its own, so the function does not wait on it).
      channelAdapters.ingress.addEnvironment("ADMIN_CHANGES", "enabled");
      // Spec 025 E14, FR-052: the interactivity route logs a press with its change's trace ID; it may
      // read only that attribute and the keys, by key.
      slackIngress.addToRolePolicy(new iam.PolicyStatement({
        actions: ["dynamodb:GetItem"],
        resources: [state.tableArn],
        conditions: {
          "ForAllValues:StringLike": { "dynamodb:LeadingKeys": ["ADMIN_CHANGE#*"] },
          "ForAllValues:StringEquals": { "dynamodb:Attributes": ["pk", "sk", "traceId"] },
          StringEqualsIfExists: { "dynamodb:Select": "SPECIFIC_ATTRIBUTES" },
          // ForAllValues passes when dynamodb:Attributes is absent, and GetItem has no Select, so a read
          // without a ProjectionExpression (which returns every attribute) must be refused outright.
          Null: { "dynamodb:Attributes": "false" },
        },
      }));
      // C14: TASK_BUSY counts the shared thread's waiting messages.
      broker.addEnvironment("SLACK_THREADS_TABLE_NAME", slackThreads.tableName);
      broker.addToRolePolicy(new iam.PolicyStatement({
        actions: ["dynamodb:GetItem"],
        resources: [slackThreads.tableArn],
        conditions: { "ForAllValues:StringLike": { "dynamodb:LeadingKeys": ["THREAD#*"] } },
      }));
    }

    const sessions = new SessionLifecycle(this, "Sessions", { naming, state, invokeSigningKey, notifyOperator });
    // Spec 065b: a project a sign-in client creates runs on the foundation's workers: the broker builds its binding from
    // the zone=subnet pairs and the launch template, with no AWS call.
    const foundationParameter = (name: string) => (this.node.findChild(name) as CfnParameter).valueAsString;
    broker.addEnvironment("EC2_WORKER_SUBNETS", foundationParameter("Ec2WorkerSubnets"));
    broker.addEnvironment("EC2_WORKER_LAUNCH_TEMPLATE_ID", foundationParameter("Ec2WorkerLaunchTemplateId"));
    // A6: where the State table expires index items itself, the reconciler's legacy sweep is off.
    if (naming.env !== undefined) sessions.reconciler.addEnvironment("INDEX_EXPIRY", "ttl");
    // Issue 195: the alarm for stuck cancels. Named environments only: the legacy template is
    // unchanged. A stuck cancel on a live worker is queued again with the signing key the backstop
    // below gives the reconciler; the legacy reconciler has none, and only logs and counts it.
    if (naming.env !== undefined) sessions.connectStuckCancelAlarm();
    // Issue 173: the backstop for idle Slack tasks nobody waits on. Named environments only: the
    // legacy template is unchanged.
    if (naming.env !== undefined) sessions.connectUnwaitedTaskBackstop(slackThreads, slackSecret, callbackSigningKey.valueAsString);
    if (naming.env !== undefined) channelAdapters.connectSlackPoster(sessions.reconciler, signInParameters.slackTeamId.valueAsString);
    // Own both attachments in this releasable stack. Secret changes must never mutate the
    // protected foundation template or require a separate foundation change set.
    grantProviderKeySecrets(this, [slackOrchestratorRole.roleName, sessions.instanceRoleName]);
    // Optional standing transport for the EC2 E2E qualification runner (CDK context
    // agentx:e2eQualificationTransport=enabled, off by default; `-c key=value` always delivers a
    // string, so only the exact string "enabled" turns it on, like agentxInstaller and agentxEval,
    // and boolean true or "true" stay off): it reads its challenge and writes its
    // proposal, ready and status files in the artifact bucket, so no run needs temporary grants.
    // The keys are scoped by the IAM policy variable ${aws:userid}, which for an EC2 instance role
    // session is <role unique ID>:<instance ID>: of the instances sharing the worker role, each can
    // reach only e2e-runtime/<its own ID>/, so a worker running other code cannot read or plant
    // another instance's files. The variable is plain text in the resource ARN (CDK treats only
    // its own ${Token[...]} markers as tokens; the test pins the synthesized text). Exact object keys
    // only: no List, Delete or wildcard object access. Attached from this stack, like the provider
    // secrets above, because the bucket lives here and the foundation template stays untouched.
    if (this.node.tryGetContext("agentx:e2eQualificationTransport") === "enabled") {
      const ownPrefix = "e2e-runtime/${aws:userid}";
      new iam.CfnPolicy(this, "E2eQualificationTransport", {
        policyName: "E2eQualificationTransport",
        roles: [sessions.instanceRoleName],
        policyDocument: {
          Version: "2012-10-17",
          Statement: [
            { Sid: "ReadQualificationChallenge", Effect: "Allow", Action: "s3:GetObject", Resource: artifacts.arnForObjects(`${ownPrefix}/challenge.json`) },
            {
              Sid: "WriteQualificationProposalReadyAndStatus", Effect: "Allow", Action: "s3:PutObject",
              Resource: [artifacts.arnForObjects(`${ownPrefix}/proposal.json`), artifacts.arnForObjects(`${ownPrefix}/ready.json`), artifacts.arnForObjects(`${ownPrefix}/status.json`)],
            },
          ],
        },
      });
      // M1.4 Task 4.9: the model canary's request and result, exact keys under the same prefix. A policy of its own, so the guarded add-only change set of the
      // qualification-transport deploy unit adds it beside the deployed grant without modifying that grant.
      new iam.CfnPolicy(this, "E2eQualificationTransportCanary", {
        policyName: "E2eQualificationTransportCanary",
        roles: [sessions.instanceRoleName],
        policyDocument: {
          Version: "2012-10-17",
          Statement: [
            { Sid: "ReadModelCanaryRequest", Effect: "Allow", Action: "s3:GetObject", Resource: artifacts.arnForObjects(`${ownPrefix}/canary-request.json`) },
            { Sid: "WriteModelCanaryResult", Effect: "Allow", Action: "s3:PutObject", Resource: artifacts.arnForObjects(`${ownPrefix}/canary-result.json`) },
          ],
        },
      });
      // M1.4 Task 4.10C, read-only model discovery for the runner's worker (what the model check lists: Bedrock models and profiles, availability, and the tokens-per-minute quotas).
      // No invoke grant is added: the driving test uses BedrockModelInvocation, which already covers the foundation models and this account's inference profiles (global. included).
      // `bedrock:GetFoundationModelAvailability` is `*` because the action has no resource type in the Service Authorization Reference. The broker needs no grant of its own for the check keys: its role already reads and writes the artifact bucket. Named like the transport policies so the
      // qualification-transport unit adds it (prefix E2eQualificationTransport); its policy name is E2eModelDiscovery.
      new iam.CfnPolicy(this, "E2eQualificationTransportDiscovery", {
        policyName: "E2eModelDiscovery",
        roles: [sessions.instanceRoleName],
        policyDocument: {
          Version: "2012-10-17",
          Statement: [
            { Sid: "ListBedrockModels", Effect: "Allow", Action: ["bedrock:ListFoundationModels", "bedrock:ListInferenceProfiles"], Resource: "*" },
            { Sid: "ReadBedrockModelAvailability", Effect: "Allow", Action: "bedrock:GetFoundationModelAvailability", Resource: "*" },
            { Sid: "ReadBedrockInferenceProfiles", Effect: "Allow", Action: "bedrock:GetInferenceProfile", Resource: `arn:${Aws.PARTITION}:bedrock:${Aws.REGION}:${Aws.ACCOUNT_ID}:inference-profile/*` },
            { Sid: "ListBedrockQuotas", Effect: "Allow", Action: "servicequotas:ListServiceQuotas", Resource: "*" },
            { Sid: "ReadBedrockQuota", Effect: "Allow", Action: "servicequotas:GetServiceQuota", Resource: `arn:${Aws.PARTITION}:servicequotas:${Aws.REGION}:${Aws.ACCOUNT_ID}:bedrock/*` },
          ],
        },
      });
    }
    // AUTOREQUALIFY (AR-2): the machine that renews the browser and API test machine by itself. CDK context agentx:autoRequalify=enabled, off by default
    // (only the exact string "enabled" turns it on); named environments only. Its resources all carry the logical-ID prefix RuntimeRequalify, so the
    // requalify-infra deploy unit adds them to a live stack with an Add-only change set. The foundation's values are the stack parameters SessionLifecycle declared.
    if (naming.env !== undefined && this.node.tryGetContext(REQUALIFY_CONTEXT_KEY) === "enabled") {
      const foundationValue = (name: string): string => (this.node.findChild(name) as CfnParameter).valueAsString;
      const hour = Number(this.node.tryGetContext("agentx:autoRequalifyHourUtc") ?? REQUALIFY_DEFAULT_HOUR_UTC);
      new RuntimeRequalify(this, "RuntimeRequalify", {
        naming, state, artifacts, invokeSigningKey, operatorTopic: operatorAlerts, notifyOperator,
        catalogIds: { setup: projectSetupRuntimeCatalogId, feature: e2eFeatureRuntimeCatalogId }, controlPlaneUrl: api.attrApiEndpoint,
        foundation: {
          privateSubnetIds: foundationValue("PrivateSubnetIds"), launchTemplateId: foundationValue("Ec2WorkerLaunchTemplateId"), workerRoleArn: foundationValue("Ec2WorkerInstanceRoleArn"),
          workspaceKmsKeyArn: foundationValue("WorkspaceKmsKeyArn"), logGroupName: naming.ec2.workerLogGroupName,
        },
        ...(Number.isInteger(hour) && hour >= 0 && hour <= 23 ? { checkHourUtc: hour } : {}),
        scheduleEnabled: this.node.tryGetContext("agentx:autoRequalifySchedule") === "enabled",
      });
    }
    sessions.steps.addEnvironment("CONTROL_PLANE_URL", api.attrApiEndpoint);
    sessions.connectDispatcher(dispatcher);
    sessions.connectBroker(broker);

    // Spec 052 FR-006, FR-011: the eval batch tick. Every 2 minutes it records run ends the broker
    // missed, reconciles the eval slot counter, fills free slots through the broker's own run path
    // (startSwebenchRun: launch.json, then the eval state machine) and writes ended batches'
    // results. It also ends runs whose execution died without ending them (Ruling 13). The schedule
    // stays on: with no batch active a tick is three small DynamoDB reads (and a slot repair when a
    // slot is held), and nothing has to switch it off. Overlapping ticks are safe: every change is a conditional write.
    // Its 90-second timeout, like the broker's 30, must stay well below EVAL_BATCH_STALE_CLAIM_MS (5 minutes,
    // eval-batch.ts): a stale claim is recovered only once the top-up that made it is dead.
    const evalBatchTick = packagedFunction(this, "EvalBatchTick", "packages/broker/src/aws/eval-batch-tick.ts", {
      STATE_TABLE_NAME: state.tableName,
      ARTIFACT_BUCKET_NAME: artifacts.bucketName,
      CALLBACK_SIGNING_KEY: callbackSigningKey.valueAsString,
      SWEBENCH_SETTINGS_PREFIX: naming.ec2.workerSettingsPrefix,
    }, Duration.seconds(90));
    state.grantReadWriteData(evalBatchTick);
    // A run's launch.json (evals/<runId>/) and a batch's results (evals/batches/<id>/); it reads nothing there.
    evalBatchTick.addToRolePolicy(new iam.PolicyStatement({ sid: "WriteEvalObjects", actions: ["s3:PutObject"], resources: [artifacts.arnForObjects("evals/*")] }));
    evalBatchTick.addToRolePolicy(new iam.PolicyStatement({ sid: "ReadEvalSettings", actions: ["ssm:GetParameters"], resources: evalSettingArns }));
    evalBatchTick.addToRolePolicy(new iam.PolicyStatement({ sid: "StartEvalRuns", actions: ["states:StartExecution"], resources: [swebenchStateMachineArn] }));
    // Ruling 16: a dead run's instance, ended before the run is charged; this environment's eval instances only.
    evalBatchTick.addToRolePolicy(new iam.PolicyStatement({
      sid: "TerminateDeadEvalInstances",
      actions: ["ec2:TerminateInstances"],
      resources: [`arn:${Aws.PARTITION}:ec2:${Aws.REGION}:${Aws.ACCOUNT_ID}:instance/*`],
      conditions: { StringEquals: { "aws:ResourceTag/DeploymentMode": SWEBENCH_DEPLOYMENT_MODE, "aws:ResourceTag/Environment": naming.environmentTagValue } },
    }));
    // Ruling 13: whether a stuck run's execution is still alive; the eval state machine's executions only.
    evalBatchTick.addToRolePolicy(new iam.PolicyStatement({
      sid: "DescribeEvalRuns",
      actions: ["states:DescribeExecution"],
      resources: [this.formatArn({ service: "states", resource: "execution", resourceName: `${swebenchNames(naming).stateMachineName}:*`, arnFormat: ArnFormat.COLON_RESOURCE_NAME })],
    }));
    new scheduler.Schedule(this, "EvalBatchTickSchedule", {
      description: "Runs the AgentX eval batch tick",
      schedule: scheduler.ScheduleExpression.rate(Duration.minutes(2)),
      target: new schedulerTargets.LambdaInvoke(evalBatchTick, {}),
    });
    new cloudwatch.Alarm(this, "EvalBatchTickErrorsAlarm", {
      alarmName: naming.alarmName("EvalBatchTickErrors"),
      alarmDescription: "The eval batch tick failed in each of the last three 5-minute periods; batches may not start runs, record ends or write results. Check the tick's logs.",
      metric: evalBatchTick.metricErrors({ period: Duration.minutes(5), statistic: "Sum" }),
      threshold: 1,
      evaluationPeriods: 3,
      comparisonOperator: cloudwatch.ComparisonOperator.GREATER_THAN_OR_EQUAL_TO_THRESHOLD,
      treatMissingData: cloudwatch.TreatMissingData.NOT_BREACHING,
    }).addAlarmAction(notifyOperator);
    // Spec 052 Ruling 31 (review M-2): the eval state machine fails an execution only at its
    // SlotReleaseFailed state, a run it could not end with its slot released. The alarm lives here,
    // where the release deploys it, rather than in the eval stack, which is deployed by hand.
    new cloudwatch.Alarm(this, "EvalExecutionsFailedAlarm", {
      alarmName: naming.alarmName("EvalExecutionsFailed"),
      alarmDescription: "An eval run's execution failed (SlotReleaseFailed): the state machine could not end the run and release its eval slot. The batch tick repairs the slot within minutes; check the execution's cause and the run's record.",
      metric: new cloudwatch.Metric({
        namespace: "AWS/States",
        metricName: "ExecutionsFailed",
        dimensionsMap: { StateMachineArn: this.formatArn({ service: "states", resource: "stateMachine", resourceName: swebenchNames(naming).stateMachineName, arnFormat: ArnFormat.COLON_RESOURCE_NAME }) },
        statistic: "Sum",
        period: Duration.minutes(5),
      }),
      threshold: 1,
      evaluationPeriods: 1,
      comparisonOperator: cloudwatch.ComparisonOperator.GREATER_THAN_OR_EQUAL_TO_THRESHOLD,
      treatMissingData: cloudwatch.TreatMissingData.NOT_BREACHING,
    }).addAlarmAction(notifyOperator);
    // Spec 052 Ruling 31 (review M-1): the Slack service's batch watcher logs each failure as an
    // eval_batch_watch.* error line, which its log group's filter counts (slack-orchestrator.ts).
    // The broker's watch list logs its own (a running batch whose channel is unbound or rebound, a
    // dropped or unreadable batch) the same way, counted here into the same metric (R-1).
    broker.logGroup.addMetricFilter("EvalBatchWatcherFailedMetric", {
      filterPattern: logs.FilterPattern.all(
        logs.FilterPattern.stringValue("$.event", "=", "eval_batch_watch.*"),
        logs.FilterPattern.stringValue("$.level", "=", "error"),
      ),
      metricNamespace: naming.metricsNamespace,
      metricName: "EvalBatchWatcherFailed",
      metricValue: "1",
    });
    new cloudwatch.Alarm(this, "EvalBatchWatcherErrorsAlarm", {
      alarmName: naming.alarmName("EvalBatchWatcherErrors"),
      alarmDescription: "The Slack service's eval batch watcher failed: a batch's thread may miss its progress or summary, or a batch was dropped. Check the Slack orchestrator and broker logs for eval_batch_watch.* errors.",
      metric: agentxSum("EvalBatchWatcherFailed", Duration.minutes(5)),
      threshold: 1,
      evaluationPeriods: 1,
      comparisonOperator: cloudwatch.ComparisonOperator.GREATER_THAN_OR_EQUAL_TO_THRESHOLD,
      treatMissingData: cloudwatch.TreatMissingData.NOT_BREACHING,
    }).addAlarmAction(notifyOperator);

    new CfnOutput(this, "ApiEndpoint", { value: api.attrApiEndpoint });
    new CfnOutput(this, "StateTableName", { value: state.tableName });
    new CfnOutput(this, "ArtifactBucketName", { value: artifacts.bucketName });
    new CfnOutput(this, "DispatchDeadLetterQueueUrl", { value: deadLetterQueue.queueUrl });
    new CfnOutput(this, "SlackEventsUrl", { value: `${api.attrApiEndpoint}/v1/slack/events` });
    new CfnOutput(this, "GithubWebhookUrl", { value: `${api.attrApiEndpoint}/v1/github/webhooks` });
    new CfnOutput(this, "SlackInteractivityUrl", { value: `${api.attrApiEndpoint}/v1/slack/interactions` });
    new CfnOutput(this, "SlackSecretArn", { value: slackSecret.secretArn });
    new CfnOutput(this, "SlackRequestQueueUrl", { value: slackRequestQueue.queueUrl });
    new CfnOutput(this, "SlackRequestDeadLetterQueueUrl", { value: slackDeadLetterQueue.queueUrl });
    new CfnOutput(this, "SlackThreadsTableName", { value: slackThreads.tableName });
    new CfnOutput(this, "SlackThreadSessionBucketName", { value: threadSessions.bucketName });
    new CfnOutput(this, "SlackOrchestratorTaskRoleArn", { value: slackOrchestratorRole.roleArn });
    new CfnOutput(this, "TurnRecordsTableName", { value: turnRecords.tableName });
    new CfnOutput(this, "OperatorAlertsTopicArn", { value: operatorAlerts.topicArn });
  }
}

export function packagedFunction(
  scope: Construct,
  id: string,
  entry: string,
  environment: Record<string, string>,
  timeout = Duration.seconds(30),
  /** Files copied beside the bundled handler, as [absolute source, name in the bundle]. */
  extraFiles: ReadonlyArray<readonly [string, string]> = [],
  memorySize = 512,
): lambdaNodejs.NodejsFunction {
  return new lambdaNodejs.NodejsFunction(scope, id, {
    runtime: lambda.Runtime.NODEJS_22_X,
    entry: resolve(process.cwd(), entry),
    handler: "handler",
    timeout,
    memorySize,
    tracing: lambda.Tracing.ACTIVE,
    environment,
    logGroup: new logs.LogGroup(scope, `${id}Logs`, {
      retention: logs.RetentionDays.ONE_MONTH,
      removalPolicy: RemovalPolicy.DESTROY,
    }),
    bundling: {
      externalModules: [],
      minify: true,
      sourceMap: true,
      target: "node22",
      ...(extraFiles.length === 0 ? {} : {
        commandHooks: {
          beforeBundling: () => [],
          beforeInstall: () => [],
          afterBundling: (_inputDir: string, outputDir: string) => extraFiles.map(([source, name]) => `cp "${source}" "${outputDir}/${name}"`),
        },
      }),
    },
  });
}
